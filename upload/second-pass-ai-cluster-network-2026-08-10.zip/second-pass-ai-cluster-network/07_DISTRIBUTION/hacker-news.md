# Hacker News

## Title options
1. How much network does an AI GPU cluster actually need?
2. A GPU cluster needs a communication deadline, not a link-rate headline
3. Deriving the network bandwidth required by an AllReduce deadline

## Suggested title
**How much network does an AI GPU cluster actually need?**

## Optional first comment
I wanted to replace “800 Gb/s per GPU sounds fast” with a workload calculation.

For an analytical n-rank ring AllReduce, per-rank payload is:

2(n-1)S/n.

Then with an effective startup term lambda:

T ≈ 2(n-1)lambda + [2(n-1)S/n]/B_eff.

So a communication deadline gives a required effective bandwidth—and a hard region where no finite bandwidth works if the startup term already exceeds the deadline.

Worked example:
64 ranks / 1 GiB / 30 ms / 2 us startup term
→ 71.1 GB/s effective required
→ 710.6 Gb/s raw at an explicit 80% efficiency scenario.

A second 256-rank case has a 1.02 ms latency floor against a 1.00 ms budget: more bandwidth alone cannot solve it.

The article also separates NVLink scale-up from Ethernet/InfiniBand scale-out, models oversubscription and converts exposed communication into GPU-equivalent capacity.

Workbook + CSVs included.

[LINK]
