# Reddit

## Title
How much network bandwidth does an AI GPU cluster actually need?

The useful answer is not a universal Gb/s/GPU number.

You need:
- collective/message bytes
- group size/algorithm
- startup latency
- communication deadline
- effective payload bandwidth
- topology/cross-section
- overlap.

For an analytical ring AllReduce:

V/rank = 2(n-1)S/n.

Worked scenario:
64 ranks
1 GiB tensor
30 ms deadline
2 us startup/step
80% network-efficiency scenario

→ 2.114 GB/rank
→ 0.252 ms latency floor
→ 71.1 GB/s required effective
→ ~710.6 Gb/s required raw line rate.

Contrasting case:
256 ranks / 1 MiB / 1 ms deadline / 2 us startup
→ latency floor = 1.02 ms
→ no finite bandwidth meets the analytical deadline.

No claim that NCCL always uses ring and no Ethernet-vs-InfiniBand winner.

[LINK]
