# Social Asset Guidance

Primary card:

**COUNT THE BYTES.**
**GIVE THEM A DEADLINE.**

64 RANKS / 1 GiB / 30 ms

**71.1 GB/s EFFECTIVE REQUIRED**

Small label:
`ANALYTICAL RING SCENARIO · λ=2 µs · NOT A MEASURED NCCL BENCHMARK`

Secondary card:

**NO FINITE BANDWIDTH**

`when startup latency floor >= communication deadline`

No vendor logos, switch photos, gradients or transport-winner language.
