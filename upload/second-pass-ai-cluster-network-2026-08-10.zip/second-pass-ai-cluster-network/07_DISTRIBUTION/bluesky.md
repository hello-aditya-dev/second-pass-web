# Bluesky

A GPU cluster does not need a universal network speed.

It needs its collective bytes to arrive before a deadline.

64-rank / 1 GiB analytical ring scenario:
30 ms budget → 71.1 GB/s effective required → ~710.6 Gb/s raw at 80% scenario efficiency.

If startup latency alone exceeds the budget, no finite bandwidth solves that model.

[LINK]
