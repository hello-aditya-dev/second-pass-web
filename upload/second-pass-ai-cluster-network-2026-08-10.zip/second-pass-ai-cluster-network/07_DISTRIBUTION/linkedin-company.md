# LinkedIn — SECOND / PASS

**COMPUTE / SECOND PASS**

**How much network does an AI GPU cluster actually need?**

The answer is not one universal Gb/s per GPU.

For a selected analytical ring case:

B_req =
payload bytes /
(deadline − startup latency floor).

64 ranks / 1 GiB / 30 ms / λ=2 µs:
**71.1 GB/s effective required.**

At an explicit 80% network-efficiency scenario:
**~710.6 Gb/s raw line rate.**

A second case demonstrates the hard limit:
256 ranks ×2(n−1) startup steps
→ 1.02 ms latency floor
→ a 1.00 ms deadline cannot be fixed by more bandwidth alone.

Full research includes current B300/GB300 topology normalization, NCCL semantics, fabric oversubscription, overlap and GPU-equivalent network exposure.

[LINK]
