# X

1/ “800 Gb/s per GPU” is not an AI-cluster network requirement.

The workload has messages.
The messages have deadlines.

Count the bytes. Subtract the latency floor. Then ask how much effective bandwidth remains necessary.

2/ Analytical ring AllReduce:

V/rank = 2(n−1)S/n

T ≈ 2(n−1)λ + V/B_eff

So:

B_req ≥ V / [T_budget − 2(n−1)λ]

3/ Worked scenario:

64 ranks
1 GiB
30 ms deadline
λ=2 µs
η=80% scenario

→ V=2.114 GB/rank
→ B_req=71.1 GB/s effective
→ raw ≈710.6 Gb/s

4/ Hard boundary:

If T_budget ≤ 2(n−1)λ,

no finite bandwidth satisfies this simplified ring model.

256 ranks ×2 µs×2 = 1.02 ms.

A 1 ms budget is already gone before serialization.

5/ Then check the fabric.

Fast NICs do not prove sufficient bisection.

And convert communication left after overlap into GPU-equivalent capacity.

[LINK]
