# LinkedIn — Personal

AI clusters are usually quoted in GPU counts and network link rates.

Neither tells you whether the workload will scale.

I built the next SECOND / PASS COMPUTE model around a different input:

**the communication deadline.**

For an analytical ring AllReduce:

per-rank payload = 2(n−1)S/n.

Communication time has two parts:
startup/latency + serialization.

In one explicit scenario:
- 64 ranks
- 1 GiB tensor
- 30 ms communication budget
- 2 µs startup term
- 80% network-efficiency assumption

the model requires:
**71.1 GB/s effective payload bandwidth**
or roughly **710.6 Gb/s raw line rate**.

An 800 Gb/s endpoint clears that scenario.

But a second 256-rank case has a 1.02 ms startup floor against a 1.00 ms deadline.

There, more bandwidth cannot solve the selected analytical ring deadline.

The research also separates:
- local HBM
- NVLink scale-up
- scale-out Ethernet/InfiniBand
- endpoint injection
- fabric bisection
- communication overlap
- GPU-equivalent capacity exposure.

No vendor winner. No random NCCL benchmark. Workbook and source CSVs included.

[LINK]
