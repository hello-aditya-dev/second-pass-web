# Direct outreach

## Subject
AI cluster network sizing from collective deadlines

I published a source-backed model for a practical cluster-planning question: given the collective bytes, group size, timing budget and topology, how much scale-out bandwidth does the workload actually require?

The model separates:
- NVLink scale-up from Ethernet/InfiniBand scale-out;
- line rate from effective payload;
- endpoint injection from bisection;
- bandwidth-limited from latency-limited regions;
- communication time from exposed communication after overlap.

It includes a company-input CSV and formula-driven workbook so the public scenarios can be replaced with real traces.

[LINK]

— Aditya
Founder & Editor, SECOND / PASS
