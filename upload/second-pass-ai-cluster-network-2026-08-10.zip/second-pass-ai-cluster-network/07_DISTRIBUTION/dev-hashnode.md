# DEV / Hashnode excerpt

## Title
Deriving the network bandwidth required by an AI collective

Excerpt:
opening → three bandwidth domains → 800G unit check → ideal ring payload → latency/bandwidth equation → required-bandwidth frontier.

Stop before the fabric/economic sections.

Footer:
> Originally published by SECOND / PASS. The canonical release includes the full topology model, GPU-equivalent exposure, CSVs and workbook.

[LINK]
