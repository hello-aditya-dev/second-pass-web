# Threads

“800 Gb/s per GPU” is a link specification, not a workload requirement.

The useful workflow:
count collective bytes → set deadline → subtract latency floor → calculate effective bandwidth → check fabric cross-section → subtract overlap.

In one transparent 64-rank scenario, the answer is ~71.1 GB/s effective.

In a smaller 256-rank case, the latency floor already exceeds the deadline—so buying a faster link does not fix the modeled problem.

[LINK]
