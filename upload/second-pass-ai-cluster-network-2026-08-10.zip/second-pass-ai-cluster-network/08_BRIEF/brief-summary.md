# SECOND / PASS / BRIEF

## Summary
An AI cluster does not have one universal network requirement. The useful input is a communication deadline for a known message and collective. In a transparent 64-rank ring scenario, a 1 GiB tensor and 30 ms budget require about 71.1 GB/s of effective payload bandwidth, or roughly 710.6 Gb/s raw line rate at an explicit 80% efficiency assumption. A contrasting 256-rank case has a 1.02 ms startup floor against a 1 ms deadline, so more bandwidth alone cannot solve it. The package also models fabric cross-section, overlap and GPU-equivalent capacity exposure.

## Best visual
`chart-03-bandwidth-frontier.svg`

## Link
**READ / HOW MUCH NETWORK DOES AN AI GPU CLUSTER ACTUALLY NEED? →**
