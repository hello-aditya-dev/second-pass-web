# PROOF HANDOFF

## Reusable mathematical objects

### Ring AllReduce payload
`V_AR = 2(n-1)S/n`

Assumptions:
- S = full tensor bytes per rank before reduction
- ideal ring ReduceScatter + AllGather
- algorithmic payload only.

### Analytical ring time
`T_AR = 2(n-1)lambda + V_AR/B_eff`

### Required effective bandwidth
`B_req = V_AR / [T_budget - 2(n-1)lambda]`

Valid only when denominator >0.

### No-finite-bandwidth boundary
`T_budget <= 2(n-1)lambda`.

### Ring latency/bandwidth crossover
`S* = n lambda B`.

### Exposed communication
`T_exposed = T_comm - T_overlap`

### GPU-equivalent exposed capacity
`G_equiv = G f_comm`.

## Future PROOF candidates
- NCCL algorithm/bus-bandwidth normalization
- tensor-parallel communication intensity
- topology-aware collective lower bounds
- all-to-all bisection model.

Do not reuse numerical scenario parameters as “typical.”
