# COMMERCIAL HANDOFF

## Product
**AI FABRIC SIZING SPRINT**

## Buyer inputs
- GPU count and node/rack layout
- scale-up domains
- candidate NIC/fabric configuration
- parallelism strategy
- representative collective trace
- message-size distribution
- group sizes and frequency
- measured startup/collective latency
- measured effective collective bandwidth
- compute time / latency SLO
- overlap traces
- fabric topology and cross-section
- GPU cost/hour or owned-hardware equivalent
- network upgrade cost.

## Outputs
- scale-up/scale-out traffic map
- per-collective byte accounting
- deadline-derived bandwidth requirements
- latency-floor / no-finite-bandwidth boundaries
- endpoint vs fabric bottleneck screen
- oversubscription sensitivity
- exposed GPU-equivalent capacity
- upgrade recovered-capacity estimate
- executive procurement brief.

## Boundary
This is capacity/performance research, not switch configuration, cabling design, guaranteed NCCL throughput or a substitute for representative system benchmarking.
