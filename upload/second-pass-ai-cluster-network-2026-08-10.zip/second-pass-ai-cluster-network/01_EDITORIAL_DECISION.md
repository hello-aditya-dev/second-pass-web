# Editorial Decision

## Final headline
**How much network does an AI GPU cluster actually need?**

The working headline remains the strongest option because the article answers the purchasing question directly. The technical answer is deliberately not a universal Gb/s-per-GPU number.

## Format
COMPUTE / SECOND PASS.

## Why it earns publication
The package contributes:
- current HGX B300 / GB300 endpoint and scale-up normalization;
- a unit/directionality reconciliation of NVIDIA networking totals;
- ideal ring collective-volume mathematics;
- a latency-bandwidth deadline equation;
- the no-finite-bandwidth decision boundary;
- bandwidth/latency crossover;
- fabric cross-section and oversubscription modeling;
- communication-overlap handling;
- GPU-equivalent capacity exposure;
- a formula-driven buyer workbook.

## Central result
For the explicit 64-rank, 1 GiB analytical ring scenario, the 30 ms communication deadline requires **71.061 GB/s effective** bandwidth. At an explicit 80% network-efficiency scenario, that is **710.612 Gb/s raw line rate**. An 800 Gb/s endpoint clears that model. A separate 256-rank, 1 MiB case has a 1.020 ms startup floor against a 1.00 ms deadline; no finite bandwidth fixes that model.

## Non-conclusions
- NCCL is not claimed to always use ring.
- 800 Gb/s is not called 100 GB/s useful payload.
- 130 TB/s NVLink is not compared directly with an 800 Gb/s scale-out endpoint.
- 2:1 oversubscription is not called a universal 2× performance loss.
- exposed communication is not synonymous with literal GPU idle time.
- no Ethernet-vs-InfiniBand winner is declared.
- no public GPU or network price is invented.
