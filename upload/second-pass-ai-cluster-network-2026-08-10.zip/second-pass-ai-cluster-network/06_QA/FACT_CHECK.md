# FACT CHECK

## Source QA — PASS
Current primary/official NVIDIA architecture, hardware, NCCL and framework documentation support the load-bearing factual claims. The original ring paper is included as algorithm history/basis.

## Hardware QA — PASS
- HGX B300: 8 GPUs / 8 ConnectX-8 in reference design.
- GB300 NVL72: 72 GPUs / 72 ConnectX-8 endpoints.
- ConnectX-8: up to 800 Gb/s; Ethernet breakout 2×400.
- GB300 scale-up: 72-GPU domain; 900 GB/s one-way / 1,800 GB/s bidirectional per GPU; ~130 TB/s aggregate.

## Calculation QA — PASS
See `CALCULATION_LEDGER.md`.

## Unit QA — PASS
See `NETWORK_UNIT_AUDIT.md`.

## Adversarial review

**Cluster network architect:** “You are sizing from endpoint line rate while ignoring fabric cross-section.”  
Fixed: endpoint and bisection/cross-section are separate model stages.

**NCCL engineer:** “Ring is not universal.”  
Fixed: ring is explicitly analytical; current NCCL algorithm selection is cited.

**GPU communication engineer:** “130 TB/s NVLink and 800G scale-out are different boundaries.”  
Fixed: Figure 01 and two Claim Checks make this explicit.

**Network performance engineer:** “800G is not 100 GB/s application payload.”  
Fixed: raw bit/byte conversion separated from effective bandwidth.

**Distributed-systems engineer:** “Small messages can be latency-limited even with high line rate.”  
Fixed: no-finite-bandwidth region and 256-rank case.

**Fabric architect:** “2:1 oversubscription does not imply 2× slowdown.”  
Fixed: impact tied to crossing traffic matrix.

**Training engineer:** “Communication can overlap compute.”  
Fixed: exposed share subtracts bounded overlap.

**CFO/procurement:** “A percentage needs an economic interpretation.”  
Fixed: GPU-equivalent exposure and buyer-supplied cost fields; no public GPU price invented.

## Factual freeze
**PASS — 2026-08-10.**

Re-opened after article, figures and workbook completion:
- HGX B300 networking logical architecture: 8 GPUs, eight ConnectX-8 800 GbE SuperNICs, 2×400 GbE breakout and dual-plane rail-optimized reference topology unchanged.
- GB300 NVL72 networking logical architecture: 72-GPU single NVLink domain, 900 GB/s one-way / 1,800 GB/s bidirectional, 18 trays ×4 ConnectX-8 and 2×400 Gb/s operation unchanged.
- ConnectX-8 port documentation: C8180 up to 800 Gb/s and two 400GbE port configuration unchanged.
- NCCL 2.30.7 collective semantics unchanged.
- NCCL 2.30.7 NCCL_ALGO list still includes Ring, Tree, CollnetDirect/Chain, NVLS/NVLSTree and PAT; default remains automatic choice based on topology/architecture.
- GB300 product page still publishes 72 GPUs and 130 TB/s NVLink bandwidth.
- HGX product page still publishes 1.6 TB/s networking bandwidth for HGX B300; the package continues to treat this as an aggregate requiring directionality reconciliation rather than a per-GPU workload rate.

No load-bearing fact changed during production.


## Cross-asset audit — PASS
Central values were matched across article, research CSVs, chart source CSVs, workbook, calculation ledger, BRIEF and distribution where used:
- 800 Gb/s = 100 GB/s raw units.
- 64-rank 1 GiB ring payload = 2,113,929,216 bytes = 2.113929216 GB.
- latency floor = 0.252 ms.
- 30 ms required effective bandwidth = 71.061221 GB/s.
- line requirement at 80% = 710.612215 Gb/s.
- predicted analytical time at 80 GB/s = 26.676115 ms.
- 256-rank small-case floor = 1.020 ms.
- fabric scenario = 102.4 Tb/s downstream / 51.2 Tb/s cut / 61.44 Tb/s crossing demand.
- 1024 GPUs ×5% = 51.2 GPU-equivalents.

No conflicting central value found.

## Senior editorial rewrite — PASS
The article stayed at procurement/capacity scope, retained the accessible working headline, and added only the source-reconciliation section needed to prevent unit/scope errors.

## Line-by-line proofreading — PASS
Grammar, punctuation, source names, network units, equation labels, directionality, scale-up/scale-out terminology, captions, alt text and metadata checked after calculation QA.

Final body: **3043 words**.
