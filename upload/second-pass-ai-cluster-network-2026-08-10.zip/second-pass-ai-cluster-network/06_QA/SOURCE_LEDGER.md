# SOURCE LEDGER

Factual snapshot/access date: **2026-08-10**.

| id | organization | document | URL | supports | limitations |
|---|---|---|---|---|---|
| S01 | NVIDIA | HGX AI Factory — Components | https://docs.nvidia.com/enterprise-reference-architectures/hgx-ai-factory/latest/components.html | HGX B300 8 GPUs, 8 ConnectX-8, NVLink and aggregate compute-network values | Some aggregate GB/s wording needs direction/scope reconciliation. |
| S02 | NVIDIA | HGX AI Factory — Networking Logical Architecture | https://docs.nvidia.com/enterprise-reference-architectures/hgx-ai-factory/latest/network-logical-architecture.html | 8 ConnectX-8, 2×400 breakout, dual-plane rail-optimized reference design, supported node counts | Reference architecture is a design point, not the only valid topology. |
| S03 | NVIDIA | NVL72 AI Factory — Components | https://docs.nvidia.com/enterprise-reference-architectures/nvl72-ai-factory/latest/components.html | 72 GPUs, 9 NVSwitch trays, 130 TB/s aggregate NVLink | Aggregate scale-up value; do not use as scale-out bandwidth. |
| S04 | NVIDIA | NVL72 AI Factory — Networking Logical Architecture | https://docs.nvidia.com/enterprise-reference-architectures/nvl72-ai-factory/latest/network-logical-architecture.html | 72-GPU L1 domain, 900/1800 GB/s NVLink per GPU, 72 ConnectX-8 endpoints, dual-plane fabric | Topology-specific reference architecture. |
| S05 | NVIDIA | ConnectX-8 User Manual — Port Configurations | https://networking-docs.nvidia.com/connectx8hw/port-configurations | 800 Gb/s adapter and 2×400GbE configuration | Line-rate hardware spec only. |
| S06 | NVIDIA | NCCL User Guide — Collective Operations | https://docs.nvidia.com/deeplearning/nccl/user-guide/docs/usage/collectives.html | AllReduce, AllGather, ReduceScatter, AlltoAll semantics | Does not specify ring as universal algorithm. |
| S07 | NVIDIA | NCCL User Guide — NCCL_ALGO | https://docs.nvidia.com/deeplearning/nccl/user-guide/docs/env.html | Current algorithm families and runtime selection behavior | Available algorithms depend on NCCL version/platform. |
| S08 | NVIDIA | Quantum-X800 InfiniBand Platform | https://www.nvidia.com/en-in/networking/products/infiniband/quantum-x800/ | 800 Gb/s InfiniBand scale-out reference | No transport winner inferred. |
| S09 | NVIDIA | Megatron Core Tensor Parallel API | https://docs.nvidia.com/megatron-core/developer-guide/latest/api-guide/tensor_parallel.html | Examples of all-reduce/all-gather/reduce-scatter/all-to-all in model-parallel mappings | Framework-specific; not universal bytes/token model. |
| S10 | Patarasuk & Yuan | Bandwidth optimal all-reduce algorithms for clusters of workstations | https://www.sciencedirect.com/science/article/pii/S0743731508001767 | Original ring-based all-reduce paper | Modern NCCL implementation can use other algorithms. |
| S11 | NVIDIA | NVIDIA HGX Platform | https://www.nvidia.com/en-in/data-center/hgx/ | HGX B300 public 1.6 TB/s networking headline used only for reconciliation | Directionality is not stated beside the headline; not used as workload-effective bandwidth. |
