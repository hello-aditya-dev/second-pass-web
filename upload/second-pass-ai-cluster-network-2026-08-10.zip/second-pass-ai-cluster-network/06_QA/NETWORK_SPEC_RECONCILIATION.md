# NETWORK SPEC RECONCILIATION

## R01 — HGX B300 aggregate network totals

**Claim/source A:** current HGX architecture uses 8 ConnectX-8 endpoints at up to 800 Gb/s each.  
**Source:** NVIDIA HGX networking logical architecture.

Raw one-direction endpoint sum:

`8 × 800 Gb/s = 6.4 Tb/s = 800 GB/s`.

**Claim/source B:** NVIDIA reference material also expresses compute-network totals as 400 GB/s for 8×400 Gb/s and 800 GB/s for 16×400 Gb/s breakout links.

**Resolution:** those GB/s values are aggregate node quantities. They are not per-GPU 400/800 GB/s values. Publication uses the explicit 800 Gb/s per endpoint plus 2×400 Gb/s plane breakout.

## R02 — HGX public “1.6 TB/s” style aggregate

A public HGX product total can appear larger than the 0.8 TB/s one-direction sum of eight 800 Gb/s endpoints.

**Resolution:** arithmetic is consistent with summing directions, but directionality is not always attached clearly to the headline. The article does not use that aggregate as a workload input.

## R03 — GB300 scale-out aggregate

72 ConnectX-8 endpoints ×800 Gb/s:

`57.6 Tb/s = 7.2 TB/s` one raw direction.

Some NVIDIA GB300 material publishes a larger aggregate networking number.

**Resolution:** arithmetic is consistent with a directional aggregate, but because the headline does not always state directionality beside the number, the model uses 72×800 Gb/s endpoints and the explicit two-plane 400G links rather than the larger aggregate.

## R04 — GB300 NVLink 130 TB/s

NVL72 RA:
- 900 GB/s one-way per GPU;
- 1,800 GB/s bidirectional per GPU;
- 72 GPUs.

`72 × 1.8 TB/s = 129.6 TB/s`, which reconciles with the published ~130 TB/s aggregate.

**Publication wording:** “roughly 130 TB/s aggregate NVLink bandwidth across the 72-GPU scale-up domain,” while preserving per-GPU directionality.

## R05 — Scale-up versus scale-out

130 TB/s NVLink aggregate and 800 Gb/s ConnectX-8 are **not comparison-safe as direct competing specifications**:
- different boundary;
- different aggregation;
- different directionality;
- different topology.

**Publication wording:** keep separate and explain traffic placement.
