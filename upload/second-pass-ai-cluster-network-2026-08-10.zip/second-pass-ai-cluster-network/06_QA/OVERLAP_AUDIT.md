# OVERLAP AUDIT

Status: **PASS**

Model:

`T_step = T_compute + T_comm - T_overlap`

with:

`0 <= T_overlap <= min(T_compute,T_comm)`.

Exposed communication:

`T_exposed = T_comm - T_overlap`.

Exposed share:

`f_comm = T_exposed/T_step`.

## Checks
- overlap assumed universal: NO.
- overlap allowed above min(compute,communication): workbook warning blocks it.
- all communication called literal idle time: NO.
- measured communication time can override analytical time: YES.
- GPU-equivalent exposed capacity labeled normalized wall-clock equivalent: YES.

**PASS**
