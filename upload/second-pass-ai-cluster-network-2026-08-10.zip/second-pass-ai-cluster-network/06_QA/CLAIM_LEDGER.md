# CLAIM LEDGER

| id | claim | class | source / derivation | confidence | caveat | publication_safe |
|---|---|---|---|---|---|---|
| C01 | HGX B300 reference design has 8 GPUs and 8 ConnectX-8 scale-out endpoints. | FACT | S01/S02 | high | Reference architecture. | YES |
| C02 | Current HGX design breaks each 800 Gb/s ConnectX-8 Ethernet endpoint into 2×400 Gb/s, one 400G leg to each plane. | FACT | S02/S05 | high | Ethernet reference design. | YES |
| C03 | GB300 NVL72 has 72 GPUs in one L1 NVLink domain, with 72 scale-out ConnectX-8 endpoints. | FACT | S03/S04 | high | Reference architecture. | YES |
| C04 | GB300 RA gives 900 GB/s one-way / 1,800 GB/s bidirectional NVLink per GPU; platform aggregate is ~130 TB/s. | FACT | S03/S04 | high | Scale-up only; aggregate wording requires direction-aware use. | YES |
| C05 | 800 Gb/s = 100 GB/s by raw bit/byte conversion. | CALCULATION | 1 byte=8 bits | exact | Does not equal useful payload throughput. | YES |
| C06 | NCCL collective semantics support AllReduce, AllGather, ReduceScatter and AlltoAll; NCCL is not ring-only. | FACT | S06/S07 | high | Algorithms/topologies dynamically selected. | YES |
| C07 | Ideal ring AllReduce payload/rank is 2(n-1)S/n. | ANALYTICAL MODEL | S10 + independent derivation | high | Algorithmic payload, not exact physical wire traffic. | YES |
| C08 | Under C07, per-rank payload approaches 2S as n grows. | CALCULATION | limit of C07 | high | Startup step count still grows. | YES |
| C09 | Simplified ring time = 2(n-1)lambda + 2(n-1)S/(n B_eff). | ANALYTICAL MODEL | alpha-beta-style derivation | high arithmetic | Effective lambda absorbs startup term; not complete NCCL prediction. | YES |
| C10 | Required B_eff = [2(n-1)S/n]/[T_budget-2(n-1)lambda] when denominator is positive. | CALCULATION | algebra from C09 | high | Scenario/model dependent. | YES |
| C11 | If deadline <= latency floor, no finite bandwidth satisfies the simplified ring model. | CALCULATION | C10 denominator | high | Does not say no algorithm/topology can solve workload. | YES |
| C12 | Primary scenario V/rank = 2113929216.0 bytes = 2.113929216 GB = 1.96875 GiB. | SCENARIO/CALCULATION | CALC-001 | high | 64 ranks, 1 GiB. | YES |
| C13 | Primary scenario requires 71.061221 GB/s effective and 710.612215 Gb/s raw at eta=0.80. | SCENARIO/CALCULATION | CALC-003 | high | eta=80% is scenario, not typical. | YES |
| C14 | Small-message case latency floor = 1.020 ms > 1.00 ms deadline. | SCENARIO/CALCULATION | CALC-005 | high | lambda=2 us scenario. | YES |
| C15 | 128×800 Gb/s = 102.4 Tb/s endpoint sum; with 51.2 Tb/s cross-section, O=2:1. | SCENARIO/CALCULATION | CALC-006 | high | Simplified capacity model, not vendor measured result. | YES |
| C16 | At 60% crossing demand, 61.44 Tb/s > 51.2 Tb/s by 10.24 Tb/s. | SCENARIO/CALCULATION | CALC-006 | high | Traffic-matrix scenario. | YES |
| C17 | Exposed capacity = G f_comm; 1024×5%=51.2 GPU-equivalents. | CALCULATION | CALC-007 | high | Not literal powered-off GPUs. | YES |
| C18 | 2:1 oversubscription always halves workload speed. | FALSE/OVERBROAD | none | high | Depends on traffic matrix. | NO |
| C19 | 800 Gb/s NIC guarantees 100 GB/s useful collective bandwidth. | FALSE/OVERBROAD | C05 | high | Raw line-rate conversion only. | NO |
| C20 | 130 TB/s NVLink makes scale-out network irrelevant. | FALSE/OVERBROAD | S03/S04 | high | Different communication boundary. | NO |
| C21 | Every AllReduce uses the ring timing model. | FALSE | S07 | high | NCCL can select other algorithms. | NO |
