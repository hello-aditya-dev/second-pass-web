# LATENCY MODEL AUDIT

Status: **PASS**

Analytical model:

`T_AR = 2(n-1)lambda + [2(n-1)S/n]/B_eff`.

Solving for bandwidth:

`B_req = [2(n-1)S/n] / [T_budget - 2(n-1)lambda]`.

Condition:

`T_budget > 2(n-1)lambda`.

If not, the selected analytical model has **NO FINITE BANDWIDTH** solution.

## Algebra
Independent rearrangement: PASS.

## Crossover
Set latency and bandwidth terms equal:

`2(n-1)lambda = 2(n-1)S/(nB)`.

Cancel `2(n-1)`:

`lambda = S/(nB)`.

Therefore:

`S* = n lambda B`.

PASS.

## Scenario checks
- 64-rank floor: 0.252 ms — PASS.
- 64-rank required effective: 71.061221 GB/s — PASS.
- 256-rank floor: 1.020 ms > 1 ms — PASS.

`lambda` is explicitly a scenario/effective startup term, not a universal physical NIC latency.

**PASS**
