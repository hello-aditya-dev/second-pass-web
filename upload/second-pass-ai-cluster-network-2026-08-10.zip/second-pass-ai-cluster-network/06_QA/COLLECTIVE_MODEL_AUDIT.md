# COLLECTIVE MODEL AUDIT

Status: **PASS**

## NCCL semantics
Current NCCL documentation confirms:
- AllReduce combines values across ranks and distributes result.
- AllGather gathers rank inputs to all ranks.
- ReduceScatter reduces and scatters rank-specific result chunks.
- AlltoAll exchanges rank-specific blocks.

## Ring model
The publication's ring case is analytical.

For full tensor S and n ranks:
- ReduceScatter payload/rank = `(n-1)S/n`
- AllGather payload/rank = `(n-1)S/n`
- AllReduce payload/rank = `2(n-1)S/n`
- analytical startup steps = `2(n-1)`.

Independent algebra: PASS.

## Guardrails
- “NCCL always uses ring”: NO.
- wire headers/retries included in payload model: NO.
- algorithmic payload called measured traffic: NO.
- AlltoAll forced into ring timing: NO.
- one tensor definition reused ambiguously without note: NO.

Current NCCL algorithm-selection documentation is cited specifically to prevent ring from being presented as universal.

**PASS**
