# NETWORK UNIT AUDIT

Status: **PASS**

## Hard conversions
- 1 byte = 8 bits.
- 800 Gb/s / 8 = **100 GB/s** raw line-rate units.
- 400 Gb/s / 8 = **50 GB/s** raw.
- 8 ×400 Gb/s = 3.2 Tb/s = **400 GB/s aggregate**.
- 16 ×400 Gb/s = 6.4 Tb/s = **800 GB/s aggregate**.
- 8 ×800 Gb/s = 6.4 Tb/s = **800 GB/s one-direction endpoint line-rate sum**.
- 72 ×800 Gb/s = 57.6 Tb/s = **7.2 TB/s one-direction endpoint line-rate sum**.

## Checks
- Gb/s confused with GB/s: NO.
- Tb/s confused with TB/s: NO.
- endpoint line rate called payload bandwidth: NO.
- aggregate called per-GPU: NO.
- bidirectional total called one-way: NO.
- NVLink scale-up aggregate compared directly with NIC scale-out line rate: NO.

## Worked-case units
- S=1 GiB = 1,073,741,824 bytes.
- per-rank ring payload = 2,113,929,216 bytes = 2.113929216 GB = 1.96875 GiB.
- required effective bandwidth = 71.061221460 GB/s.
- required raw line at eta=.80 = 710.612214603 Gb/s.

**PASS**
