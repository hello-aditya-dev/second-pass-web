# BENCHMARK LEDGER

## Status
**NO MEASURED NCCL / NETWORK PERFORMANCE BENCHMARK IS LOAD-BEARING IN THIS RELEASE.**

The publication uses:
- current official hardware/network specifications;
- current NCCL operation semantics;
- an analytical ring model;
- original scenario calculations.

No `nccl-tests` algorithm-bandwidth or bus-bandwidth number is imported as universal application throughput.

| hardware | GPUs | nodes | NIC/fabric | collective | message | NCCL version | bandwidth type | value | use |
|---|---:|---:|---|---|---|---|---|---|---|
| — | — | — | — | — | — | — | — | — | No measured benchmark used |

This avoids conflating NCCL algorithm bandwidth, bus bandwidth, wire line rate and application payload bandwidth.
