# TOPOLOGY AUDIT

Status: **PASS**

## Boundaries
- local HBM: separate.
- scale-up NVLink/NVSwitch: separate.
- scale-out Ethernet/RoCE or InfiniBand: separate.

## Endpoint vs fabric
Aggregate endpoint injection is not treated as:
- bisection bandwidth;
- guaranteed useful collective throughput;
- simultaneously achievable application bandwidth.

## Oversubscription
Defined as `O=D/U` for the selected simplified switching stage.

The article does NOT say:
- 2:1 oversubscription always halves performance;
- non-blocking means zero congestion;
- rail optimization eliminates contention.

## NVIDIA design point
Current HGX/GB300 reference architectures are described as rail-optimized dual-plane designs. They are explicitly treated as documented design points, not the only valid topology.

## Fabric scenario
128×800G / 51.2 Tb/s / 60% crossing is explicitly a SCENARIO, not measured Spectrum-X performance.

**PASS**
