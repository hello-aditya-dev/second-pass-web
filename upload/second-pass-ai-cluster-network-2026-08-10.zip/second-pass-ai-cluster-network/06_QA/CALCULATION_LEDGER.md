# CALCULATION LEDGER

Independent reproduction date: **2026-08-10**.

## CALC-001 — 64-rank ring payload
Inputs: n=64, S=1 GiB=1,073,741,824 bytes.

`V = 2*(63/64)*1,073,741,824 = 2,113,929,216 bytes`.

= **2.113929216 GB decimal**  
= **1.96875 GiB**.

Steps: `2*(64-1)=126`.

**PASS**

## CALC-002 — Latency floor
lambda=2 us/step.

`126*2 us = 252 us = 0.252 ms`.

**PASS**

## CALC-003 — Required bandwidth
Compute=270 ms; allowed no-overlap comm share f=0.10.

Deadline:
`f/(1-f)*270 = 30.000000000000 ms`.

Serialization budget:
`30 - 0.252 = 29.748 ms`.

Required effective:
`2,113,929,216 / 0.029748 = 71,061,221,460.266235 B/s = 71.061221460266 GB/s`.

At eta=0.80:
raw line = `71.061221460266/0.8 = 88.826526825333 GB/s`
= **710.612214602662 Gb/s**.

**PASS**

## CALC-004 — Predicted communication at 800 Gb/s × 80%
800 Gb/s = 100 GB/s raw.

Effective = 80 GB/s.

Bandwidth time:
`2113929216.0/80e9 = 26.424115200 ms`.

Total analytical:
`0.252 + 26.424115200 = 26.676115200 ms`.

No-overlap total step:
`270 + 26.676115200 = 296.676115200 ms`.

Communication/exposed share:
`0.089916625685 = 8.991663%`.

**PASS**

## CALC-005 — No finite bandwidth case
n=256, S=1 MiB, lambda=2 us, budget=1.00 ms.

Latency floor:
`2*(255)*2 us = 1.020 ms`.

`1.00 ms <= 1.020 ms`.

Therefore no finite bandwidth satisfies the selected analytical ring deadline.

**PASS**

## CALC-006 — Fabric capacity scenario
128 endpoints ×800 Gb/s = **102.4 Tb/s** downstream line-rate sum.

Uplink/cross-section = 51.2 Tb/s.

Oversubscription:
`102.4/51.2 = 2.0`.

60% crossing demand:
`102.4*0.60 = 61.44 Tb/s`.

Deficit:
`61.44-51.2 = 10.24 Tb/s`.

**PASS**

## CALC-007 — GPU-equivalent exposure
`1024*0.05 = 51.2` GPU-equivalents.

No dollar price assumed.

**PASS**

## CALC-008 — Ring latency/bandwidth crossover
Set latency term equal to serialization term.

`S* = n*lambda*B_eff`.

`64*2e-6*80e9 = 10,240,000 bytes`
= **10.24 MB decimal**
= **9.765625 MiB**.

**PASS**

## CALC-009 — AlltoAll balanced payload accounting
If D bytes originate at each rank and routing is perfectly balanced, remote payload/rank is approximately `D(n-1)/n`.

No universal timing equation is imposed because topology/routing/imbalance are workload inputs.

**PASS**

## CALC-010 — Economics
Exposed GPU-equivalent capacity:
`G_equiv = G*f_comm`.

Exposure/hour:
`C = G*C_g*f_comm`.

Recovered capacity:
`Delta G = G(f1-f2)`.

No public GPU or network price used.

**PASS**
