# SECOND / PASS — COMPUTE / SECOND PASS #03

## Article
**How much network does an AI GPU cluster actually need?**

Canonical:
`02_ARTICLE/how-much-network-does-an-ai-gpu-cluster-actually-need.md`

Format: SECOND PASS  
Section: COMPUTE  
Author: Aditya  
Status: review  
Research date: 2026-08-10

## Central findings
- scale-up and scale-out bandwidth are different resources.
- ideal ring AllReduce payload/rank: `2(n-1)S/n`.
- 64-rank / 1 GiB / 30 ms case: 71.061 GB/s required effective bandwidth.
- at 80% scenario efficiency: 710.612 Gb/s required raw line rate.
- 256-rank / 1 MiB / 1 ms case: latency floor 1.020 ms → NO FINITE BANDWIDTH under the analytical ring model.
- 1024 GPUs × 5% exposed share = 51.2 GPU-equivalents of normalized capacity exposure.

## Contents
- canonical 2,900–3,700 word article
- 6 required research CSVs
- 11-sheet formula-driven workbook
- 5 SVG + 5 PNG evidence figures and source CSVs
- network-spec reconciliation and unit audit
- collective, latency, topology, overlap and vendor-fairness QA
- distribution package
- BRIEF
- PROOF/DATA/commercial/site handoffs.

## Human gate
Do not publish or deploy. Status remains `review`.

## Finalization
Factual freeze, control-character scan and final ZIP inspection occur immediately before delivery.

## Final QA
Factual freeze: PASS  
Control-character audit: PASS  
Workbook formula errors: 0  
Five-figure visual QA: PASS  
Cross-asset audit: PASS  
Archive provisional inspection: PASS  
Final state: READY FOR HUMAN REVIEW.
