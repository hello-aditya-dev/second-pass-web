# FOLLOW-UP EXTRACTIONS

1. **Why NCCL bus bandwidth is not NIC line rate**
2. **The network Roofline for tensor parallel inference**
3. **KV-cache disaggregation creates a different network budget**
4. **MoE all-to-all: when bisection matters more than endpoint speed**
5. **Measuring effective collective bandwidth instead of quoting 800G**
6. **Rail optimization: what it fixes and what it cannot fix**
7. **When adding GPUs increases communication steps faster than useful throughput**
8. **How to price recovered GPU capacity from a fabric upgrade**

Each follow-up requires a fresh source and benchmark check at drafting time.
