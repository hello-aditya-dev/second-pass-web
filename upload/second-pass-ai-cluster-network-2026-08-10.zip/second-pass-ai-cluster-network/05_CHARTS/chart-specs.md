# Chart Specifications

Palette: Paper `#F2EFE7` · Ink `#11110F` · Graphite `#5A5953` · Rule `#C9C3B7` · Signal Blue `#2F5BFF`.  
No gradients, vendor-color battles, rack photography, glowing network lines or generic cloud icons.

## Figure 01 — Three bandwidth domains
**figure_id:** `chart-01-bandwidth-domains`  
**decision question:** Which bandwidth boundary is being discussed?  
**title:** THREE BANDWIDTH DOMAINS — DO NOT COLLAPSE THEM  
**data:** `data/chart-01-bandwidth-domains.csv`  
**units:** GB/s and Gb/s, explicitly normalized  
**source:** NVIDIA HGX/GB300 reference architectures and ConnectX-8 documentation  
**classification:** FACT + UNIT NORMALIZATION  
**assumptions:** local HBM and scale-up examples are current NVIDIA references; scale-out 800 Gb/s is raw line rate.  
**caveat:** the three values solve different communication boundaries and are not a direct performance ranking.  
**alt text:** Three boxes distinguish B300 local HBM at 8 TB/s per GPU, GB300 scale-up NVLink at 900 GB/s one-way per GPU, and ConnectX-8 scale-out at 800 Gb/s, equal to 100 GB/s raw line rate per GPU.  
**caption:** Local HBM, scale-up NVLink and scale-out NIC bandwidth are different resources. Normalize units and scope before comparing any number.  
**mobile behavior:** stack the three cards vertically below 430px; keep scope label attached to value.

## Figure 02 — What one AllReduce moves
**figure_id:** `chart-02-ring-allreduce`  
**decision question:** How does a tensor of S bytes turn into per-rank network payload?  
**title:** WHAT ONE IDEAL RING ALLREDUCE MOVES  
**data:** `data/chart-02-ring-allreduce.csv`  
**units:** bytes / GB / GiB per rank  
**source:** analytical ring model; NCCL operation semantics; Patarasuk & Yuan ring all-reduce reference  
**classification:** CALCULATION / ANALYTICAL MODEL  
**assumptions:** n=64; S=1 GiB full tensor/rank; ring ReduceScatter + AllGather; physical protocol traffic omitted.  
**caveat:** NCCL does not always select ring; headers, retries, chunking and implementation can change physical traffic.  
**alt text:** ReduceScatter and AllGather each move n-minus-one over n times the tensor per rank; together an ideal 64-rank ring AllReduce moves 2.114 GB or 1.96875 GiB per rank in 126 analytical steps.  
**caption:** Under the ideal ring-volume model, per-rank AllReduce payload approaches 2S as rank count grows even though the number of communication steps keeps increasing.  
**mobile behavior:** stack ReduceScatter and AllGather cards; keep total equation below.

## Figure 03 — Required bandwidth frontier
**figure_id:** `chart-03-bandwidth-frontier`  
**decision question:** How much effective bandwidth is required to meet a collective deadline, and when can bandwidth no longer solve it?  
**title:** REQUIRED EFFECTIVE BANDWIDTH HAS A LATENCY WALL  
**data:** `data/chart-03-bandwidth-frontier.csv`  
**units:** deadline ms; required effective GB/s  
**source:** original latency-bandwidth calculation  
**classification:** SCENARIO / CALCULATION  
**assumptions:** 64-rank analytical ring; 1 GiB tensor; lambda=2 microseconds/step; explicit 30 ms worked case; 80 GB/s effective reference line is 800 Gb/s × 80% scenario efficiency.  
**caveat:** lambda and network efficiency are scenarios, not measured NCCL values; the curve is not a runtime benchmark.  
**alt text:** Log-scale deadline chart with a shaded no-finite-bandwidth region below the 0.252 millisecond latency floor and a decreasing required-bandwidth curve; the 30 millisecond worked case requires about 71.1 GB/s effective bandwidth.  
**caption:** Required bandwidth is payload divided by the serialization time left after startup latency consumes part of the deadline. If the latency term alone exceeds the deadline, no finite bandwidth satisfies this analytical ring model.  
**mobile behavior:** full-width with internal horizontal scroll below 390px; never remove the shaded infeasible region.

## Figure 04 — Fabric oversubscription
**figure_id:** `chart-04-fabric-oversubscription`  
**decision question:** Why can every GPU have a fast NIC while cross-cluster traffic still hits a fabric limit?  
**title:** FAST ENDPOINTS CAN STILL HIT A FABRIC CROSS-SECTION  
**data:** `data/chart-04-fabric-oversubscription.csv`  
**units:** Gb/s and Tb/s  
**source:** original normalized fabric-capacity scenario  
**classification:** SCENARIO / CALCULATION  
**assumptions:** 128 endpoints ×800 Gb/s; 51.2 Tb/s modeled uplink/bisection; 60% crossing traffic.  
**caveat:** not measured Spectrum-X or InfiniBand performance; 2:1 oversubscription does not imply universal 2× slowdown.  
**alt text:** A simplified fabric shows 128 800-gigabit endpoints totaling 102.4 terabits per second feeding a 51.2-terabit cross-section; 60 percent crossing demand equals 61.44 terabits per second and exceeds the cut by 10.24 terabits per second.  
**caption:** Endpoint injection and fabric cross-section are separate capacities. Application impact depends on the traffic matrix and how much traffic actually crosses the constrained cut.  
**mobile behavior:** stack endpoint, cross-section and crossing-demand cards vertically.

## Figure 05 — Network exposure in GPU equivalents
**figure_id:** `chart-05-gpu-network-exposure`  
**decision question:** What does exposed communication share mean economically at cluster scale?  
**title:** SMALL COMMUNICATION SHARES BECOME LARGE AT CLUSTER SCALE  
**data:** `data/chart-05-gpu-network-exposure.csv`  
**units:** exposed share; GPU-equivalent capacity  
**source:** original sensitivity calculation  
**classification:** MATHEMATICAL SENSITIVITY  
**assumptions:** 1024 GPUs; shares 1%, 2%, 5%, 10%, 20%.  
**caveat:** GPU-equivalent exposed capacity is a normalized wall-clock capacity fraction, not literal powered-off or always-idle GPUs.  
**alt text:** Bars show that exposed communication shares of 1, 2, 5, 10 and 20 percent on a 1024-GPU cluster correspond to 10.2, 20.5, 51.2, 102.4 and 204.8 GPU-equivalents.  
**caption:** A small exposed communication share scales linearly with fleet size. Dollar value remains a buyer input rather than a public GPU-price assumption.  
**mobile behavior:** full-width; preserve bar labels.
