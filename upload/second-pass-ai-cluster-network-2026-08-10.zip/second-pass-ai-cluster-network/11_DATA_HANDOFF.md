# DATA HANDOFF

## Public-ready research datasets
- `03_RESEARCH/network-hardware-reference-2026-08-10.csv`
- `03_RESEARCH/collective-communication-model.csv`
- `03_RESEARCH/required-network-bandwidth-surface.csv`
- `03_RESEARCH/fabric-capacity-scenarios.csv`
- `03_RESEARCH/network-exposure-sensitivity.csv`
- `03_RESEARCH/ai-cluster-network-input-template.csv`

## Chart data
Five source CSVs in `05_CHARTS/data/`.

## Data classifications
- hardware rows: FACT / normalized current primary-source data
- ring rows: ANALYTICAL MODEL
- frontier/fabric/exposure rows: SCENARIO / CALCULATION
- no measured NCCL benchmark is present.

## Unit contract
- line rates stored in Gb/s or Tb/s as named.
- payload bandwidth stored in GB/s when named.
- bytes stored as integer bytes.
- time dimensions name seconds/ms/us explicitly.
- never infer directionality from an aggregate without source wording.

## Reproduction
Central calculations are duplicated in `06_QA/CALCULATION_LEDGER.md` and the formula-driven workbook.
