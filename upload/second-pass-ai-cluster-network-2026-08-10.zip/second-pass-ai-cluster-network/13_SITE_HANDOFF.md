# SITE HANDOFF

## Canonical article
`02_ARTICLE/how-much-network-does-an-ai-gpu-cluster-actually-need.md`

- slug: `how-much-network-does-an-ai-gpu-cluster-actually-need`
- section: COMPUTE
- format: SECOND PASS
- author: Aditya
- status: review
- featured: true
- one canonical Markdown source
- renderer owns H1
- FIRST PASS from frontmatter
- `changeLog: []`.

## Figure order
1. `chart-01-bandwidth-domains.svg`
2. `chart-02-ring-allreduce.svg`
3. `chart-03-bandwidth-frontier.svg`
4. `chart-04-fabric-oversubscription.svg`
5. `chart-05-gpu-network-exposure.svg`

Use SVG primary / PNG fallback. Source CSVs are in `05_CHARTS/data/`.

## Labels that must remain attached
- `raw line rate`
- `effective bandwidth`
- `scale-up`
- `scale-out`
- `ANALYTICAL RING MODEL`
- `SCENARIO`
- `NO FINITE BANDWIDTH`
- `not literal powered-off GPUs`.

## Mobile
Verify 1440 / 1024 / 820 / 768 / 430 / 390 / 375.
- Figure 01: stack cards.
- Figure 02: stack collective phases.
- Figure 03: allow internal horizontal scroll; preserve shaded infeasible region.
- Figure 04: stack topology cards.
- Figure 05: keep numeric labels.
No page-level horizontal overflow.

## Public downloads
- `04_MODEL/ai-cluster-network-capacity-model.xlsx`
- `03_RESEARCH/ai-cluster-network-input-template.csv`
- selected supporting CSVs.

## House objects
`/ QUESTION`, `/ ASSUMPTION`, `/ CALCULATION`, `/ CLAIM CHECK`, `/ INTELLIGENCE`.

## Source handling
Natural public links only. Keep S01-style IDs in QA files.

## Private QA
`01_EDITORIAL_DECISION.md`, `06_QA/*`, `09_FOLLOWUPS/*`, `10_PROOF_HANDOFF.md`, `11_DATA_HANDOFF.md`, `12_COMMERCIAL_HANDOFF.md`.

## Z.ai
Do not re-research or reinterpret current findings. Preserve `status: review` until explicit human approval.
