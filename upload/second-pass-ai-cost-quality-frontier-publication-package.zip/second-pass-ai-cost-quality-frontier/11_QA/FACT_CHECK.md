# FACT CHECK — Adversarial Pass

## Volatility
- [x] Every current price claim has a 2026-08-09 source-access date.
- [x] Sonnet 5 temporary pricing is date-qualified.
- [x] xAI Batch support is phrased as “currently” and sourced.

## Configuration integrity
- [x] Model and configuration are not conflated.
- [x] Standard and Batch rows are separate.
- [x] Long-context bands are separate where providers expose them.
- [x] Cache write, cache hit and cache storage are not conflated.
- [x] Fast/Priority modifiers are described but not merged into standard rows.

## Tokenization
- [x] Cross-provider nominal-token examples are explicitly labelled non-text-equivalent.
- [x] Anthropic tokenizer note is labelled as provider documentation.
- [x] No single tokenizer count is reused as same-text evidence across providers.

## Quality
- [x] No provider benchmark is presented as production success.
- [x] No independent benchmark is mixed with a provider benchmark in a composite score.
- [x] No actual Sol-vs-Luna review or success-rate difference is claimed.
- [x] Scenario review rates are visibly marked assumptions.

## Hardware / energy
- [x] AWS H200 rental price is not treated as accelerator purchase price.
- [x] NVIDIA maximum TDP is not treated as energy/request.
- [x] IEA data-centre electricity is not attributed wholly to AI inference.

## Arithmetic / units
- [x] Token-price calculations use USD/1,000,000 tokens.
- [x] Human review uses hours × USD/hour.
- [x] Percentage-point threshold converts a dimensionless probability by ×100.
- [x] Cache inequality checked independently.
- [x] Long-context multipliers checked against source values.

## Causality
- [x] The article says what would make a stronger model cheaper; it does not claim the stronger model causes that improvement.
- [x] Routing literature is used to establish method families, not to forecast SECOND / PASS scenario savings.

## Baselines
- [x] Every relative percentage in the flagship states its baseline.
- [x] The 32.7% scenario reduction is relative to the Luna model+review total and remains scenario-labelled.

## Result
PASS
