# CALCULATION LEDGER

## CALC-001 — Sol/Luna token-rate ratio
- **question:** What is the short-context public list-price ratio?
- **inputs:** Sol input 5, Luna input 0.2; Sol output 30, Luna output 1.2
- **units:** USD/MTok
- **formula:** `price_expensive / price_cheap`
- **substitution:** `5/0.2 = 25`; `30/1.2 = 25`
- **result:** 25×
- **rounding:** exact from published decimal prices
- **assumptions:** public list price; short context; standard tier
- **sources:** S1-S3
- **interpretation:** relative token-price gap
- **limitations:** not a quality or per-task comparison

## CALC-002 — Direct per-attempt costs
- **question:** What does 10k input + 1k output cost?
- **inputs:** 10,000 input; 1,000 output
- **formula:** `Tin/1e6*Pin + Tout/1e6*Pout`
- **Luna:** `10000/1e6*0.20 + 1000/1e6*1.20 = 0.0032`
- **Sol:** `10000/1e6*5 + 1000/1e6*30 = 0.0800`
- **result:** Luna $0.0032; Sol $0.0800
- **sources:** S1
- **limitations:** no cache, tools, retries or reasoning-output differential

## CALC-003 — Incremental token cost
- **formula:** `0.0800 − 0.0032`
- **result:** **$0.0768**

## CALC-004 — Review-event cost
- **inputs:** 3 minutes; $90/hour
- **units:** minutes, USD/hour
- **formula:** `3/60*90`
- **result:** **$4.50**
- **type:** ASSUMPTION, not sourced labor-market data
- **sensitivity:** chart-01 varies review cost from $0.50 to $10.

## CALC-005 — Review-rate break-even
- **formula:** `incremental_direct_cost / review_event_cost`
- **substitution:** `0.0768/4.50`
- **result:** `0.0170667` = **1.71 percentage points**
- **rounding:** two decimal percentage points
- **interpretation:** required avoided review incidence to pay for higher direct model cost
- **limitations:** holds other downstream terms equal

## CALC-006 — Illustrative model+review totals
- **assumptions:** Luna review 10%; Sol review 5%; review $4.50
- **Luna:** `0.0032 + 0.10*4.50 = 0.4532`
- **Sol:** `0.0800 + 0.05*4.50 = 0.3050`
- **difference:** `$0.1482`
- **relative reduction versus Luna:** `0.1482/0.4532 = 32.70%`
- **publication rule:** must remain labelled scenario

## CALC-007 — 1.25× cache-write break-even
- **formula:** `1.25 + 0.10(N−1) < N`
- **solution:** `N > 1.277777...`
- **integer threshold:** **2 uses**
- **sources:** S1,S4
- **limitations:** excludes TTL, minimum prefix and hit probability

## CALC-008 — 2× cache-write break-even
- **formula:** `2 + 0.10(N−1) < N`
- **solution:** `N > 2.111111...`
- **integer threshold:** **3 uses**
- **source:** S4

## CALC-009 — Batch multiplier
- **inputs:** Standard/Batch pairs in S1,S4,S6
- **formula:** `Batch / Standard`
- **result:** 0.5 for included input/output price pairs
- **interpretation:** 50% token-charge reduction for eligible Batch work
- **limitation:** latency and eligibility differ

## CALC-010 — Long-context multipliers
- **OpenAI GPT-5.6 Sol:** input `10/5=2.0×`; output `45/30=1.5×`
- **xAI Grok 4.5:** input `4/2=2.0×`; output `12/6=2.0×`
- **Anthropic Opus 5:** documented standard rate across full 1M context = `1.0×`
- **sources:** S1,S2,S4,S8
- **limitation:** thresholds differ; not a same-context capability comparison
