# CLAIM LEDGER

| claim_id | claim | type | importance | evidence | calculation | confidence | caveat | publication-safe |
|---|---|---|---|---|---|---|---|---|
| C01 | $/M tokens is insufficient as a production economic denominator. | INFERENCE | thesis | S1,S4,S5,S6,S8 + cost model | CAO framework | high | Requires workload-specific acceptance definition. | yes |
| C02 | GPT-5.6 Sol short-context input/output rates are 25× Luna. | CALCULATION from FACT | high | S1-S3 | 5/0.2 = 30/1.2 = 25 | high | Public list prices only. | yes |
| C03 | On 10k input + 1k output, Luna direct cost is $0.0032 and Sol is $0.0800. | CALCULATION | high | S1 | token arithmetic | high | Same provider family and nominal request shape. | yes |
| C04 | Incremental direct cost in that example is $0.0768. | CALCULATION | high | C03 | 0.0800−0.0032 | high | Same scenario. | yes |
| C05 | At $4.50/review, 1.71 pp less review offsets $0.0768. | CALCULATION | thesis | C04 + explicit assumption | 0.0768/4.50 | high | Does not assert actual model review rates. | yes |
| C06 | Under assumed 10% vs 5% review rates, Sol model+review cost is lower. | CALCULATION / ASSUMPTION | medium | C03 + scenario | 0.4532 vs 0.3050 | high arithmetic | Scenario only; not empirical performance. | yes, only with labels |
| C07 | A 1.25× write + 0.10× read structure crosses cache break-even on the second eligible use. | CALCULATION | high | S1,S4 | N>(1.25−.1)/.9 | high | Eligibility/TTL/hit probability excluded. | yes |
| C08 | A 2× one-hour write + 0.10× reads crosses on the third eligible use. | CALCULATION | medium | S4 | N>(2−.1)/.9 | high | Eligibility/TTL/hit probability excluded. | yes |
| C09 | Included OpenAI/Anthropic/Google Batch token rates are 50% below Standard. | FACT/CALCULATION | high | S1,S4,S6 | Batch/Standard = .5 | high | Eligibility and completion latency differ. | yes |
| C10 | Long-context pricing is provider/configuration-specific. | FACT + INFERENCE | high | S1,S2,S4,S8 | chart-05 multipliers | high | Thresholds differ. | yes |
| C11 | Sonnet 5 introductory price ends 2026-08-31; announced standard price starts 2026-09-01. | FACT | high/volatile | S4,S5 | none | high | Reverify at publish time. | yes |
| C12 | Anthropic says its newer tokenizer can produce approximately 30% more tokens for the same text than Sonnet 4.6. | VENDOR CLAIM | medium | S4,S5 | none | medium-high | Exact change is workload-dependent. | yes |
| C13 | LLM routing literature supports dynamic and sequential routing formulations. | INDEPENDENT RESULT summary | medium | S14-S17 | none | high | Reported benchmark savings are not enterprise forecasts. | yes |
| C14 | Sol actually reduces review by at least 1.71 pp versus Luna. | HYPOTHESIS | high | none | none | unknown | No workload measurement. | **no** |
| C15 | Self-hosting is cheaper than API at a specific volume. | HYPOTHESIS | medium | incomplete | incomplete | unknown | Missing equivalent throughput/CapEx/ops. | **no** |
| C16 | H200 TDP can be used as energy/request. | INVALID ASSUMPTION | medium | S12 | none | low | TDP is not measured inference energy. | **no** |
