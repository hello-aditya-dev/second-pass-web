# SOURCE LEDGER

Access date for web sources unless otherwise stated: **2026-08-09**.

| source_id | organization | document/page | URL | source_type | primary/secondary | effective_date | claims_supported | limitations |
|---|---|---|---|---|---|---|---|---|
| S1 | OpenAI | API Pricing | https://developers.openai.com/api/docs/pricing | official documentation | primary |  | OpenAI standard/Batch/Fast/context-band/cache pricing | List price; not enterprise effective price. |
| S2 | OpenAI | GPT-5.6 Sol | https://developers.openai.com/api/docs/models/gpt-5.6-sol | official documentation | primary |  | Sol >272k long-context threshold and cache-write rule | Provider documentation; no production-outcome quality. |
| S3 | OpenAI | GPT-5.6 Luna | https://developers.openai.com/api/docs/models/gpt-5.6-luna | official documentation | primary |  | Luna pricing and >272k threshold | Provider documentation; no production-outcome quality. |
| S4 | Anthropic | Claude pricing | https://docs.anthropic.com/en/docs/about-claude/pricing | official documentation | primary |  | Claude prices, cache multipliers, Batch, Fast, 1M context, tokenizer note | List price; tokenizer statement is provider documentation. |
| S5 | Anthropic | What's new in Claude Sonnet 5 | https://docs.anthropic.com/en/docs/about-claude/models/whats-new-sonnet-5 | official documentation | primary | 2026-09-01 price step | Sonnet 5 introductory/standard price dates and tokenizer change | Temporary/future pricing; must be date-qualified. |
| S6 | Google | Gemini Developer API pricing | https://ai.google.dev/gemini-api/docs/pricing | official documentation | primary |  | Standard/Batch/Flex/Priority/cache pricing and thinking-token accounting | List price; provider-specific thinking-token accounting. |
| S7 | Mistral AI | Mistral Small 4 model card | https://docs.mistral.ai/models/model-cards/mistral-small-4-0-26-03 | official model card | primary |  | Mistral Small 4 price, context, license, architecture size | Provider performance claims are not used in flagship. |
| S8 | xAI | API pricing | https://docs.x.ai/developers/pricing | official documentation | primary |  | Grok 4.5 short/long-context pricing and threshold | List price; no enterprise discount. |
| S9 | xAI | Grok 4.5 | https://docs.x.ai/developers/grok-4-5 | official model page | primary |  | Grok 4.5 context and reasoning configuration | Provider model description; benchmark claims not used. |
| S10 | xAI | Batch API | https://docs.x.ai/developers/advanced-api-usage/batch-api | official documentation | primary |  | Grok 4.5 currently unsupported by Batch | Capability status can change. |
| S11 | AWS | EC2 Capacity Blocks for ML pricing | https://aws.amazon.com/ec2/capacityblocks/pricing/ | official pricing | primary |  | Observable H200 cloud-rental reference | Rental rate is not hardware purchase price or owned TCO. |
| S12 | NVIDIA | H200 Tensor Core GPU | https://www.nvidia.com/en-us/data-center/h200/ | official technical specification | primary |  | H200 memory, bandwidth and maximum TDP | TDP is not measured inference energy. |
| S13 | IEA | Key Questions on Energy and AI — Executive Summary | https://www.iea.org/reports/key-questions-on-energy-and-ai/executive-summary | official research | primary |  | Data-centre electricity projections | Aggregate data-centre electricity cannot be attributed directly to inference. |
| S14 | Ong et al. | RouteLLM | https://arxiv.org/abs/2406.18665 | original research paper | primary |  | Learned strong/weak LLM routing with preference data | Benchmark routing results do not forecast enterprise savings. |
| S15 | Chen et al. | FrugalGPT | https://arxiv.org/abs/2305.05176 | original research paper | primary |  | LLM cascades and cost-quality routing | Historical model/API environment differs from 2026. |
| S16 | Xu et al. | SeqRoute | https://arxiv.org/abs/2605.25424 | original research paper | primary |  | Budget-aware sequential routing formulation | Research setting, not deployment guarantee. |
| S17 | Zhang et al. | Budget-Aware Agentic Routing | https://arxiv.org/abs/2602.21227 | original research paper | primary |  | Agentic routing as sequential/path-dependent | Research setting, not deployment guarantee. |
| S18 | R2-Router authors | R2-Router | https://arxiv.org/abs/2602.02823 | original research paper | primary |  | Joint model/output-budget routing concept | Used for follow-up framing; not a production forecast. |
