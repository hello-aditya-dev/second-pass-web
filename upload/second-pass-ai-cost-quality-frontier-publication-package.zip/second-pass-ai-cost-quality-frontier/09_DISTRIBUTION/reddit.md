# Reddit

## Suggested post title
A break-even way to compare LLMs: cost per accepted outcome, not $/M tokens

## Body
I kept seeing model-cost comparisons stop at input/output token rates, so I normalized the problem differently.

The useful question for a production workload is: how much must a more expensive configuration reduce retries, review or failure to offset its direct model premium?

One worked example uses current GPT-5.6 short-context list prices. Sol is 25× Luna per input/output token. For a nominal 10k-input/1k-output task, however, the absolute direct-cost difference is $0.0768. If a human review event costs $4.50, the break-even reduction in review incidence is 1.71 percentage points.

That is not a claim that Sol actually reduces review by that amount. It is the threshold the workload evaluation has to test.

I also separated Batch, cache and context bands in the dataset because a model name alone is not a price key. The methodology page includes retry equations and the routing formulation; the CSV is a dated snapshot rather than a “live price leaderboard.”

Interested in criticism of the denominator and any production failure terms I have omitted.

[LINK]
