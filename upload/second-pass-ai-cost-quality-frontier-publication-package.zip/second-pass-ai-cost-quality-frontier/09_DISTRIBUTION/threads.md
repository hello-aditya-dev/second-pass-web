# Threads

A useful way to compare AI models:

Don't ask only “what is the $/M token price?”

Ask “what improvement would make the more expensive configuration cheaper overall?”

On one current-price example, a 25× token-rate gap becomes only $0.0768 per 10k-input/1k-output task.

If a human review costs $4.50, avoiding 1.71 percentage points of review pays for the entire difference.

That is the number to test on the real workload.

[LINK]
