# Hacker News

## Suggested title
The cheapest AI model is often not the cheapest system

## Submission
Link directly to the flagship. No promotional subtitle.

## Optional first comment
I built a small configuration-level price snapshot and a break-even model for moving from $/token to $/accepted outcome.

The worked example does not assume one model is better. It asks how much review reduction would be required to pay for a higher token price. Current GPT-5.6 Sol/Luna rates make that threshold 1.71 percentage points under a $4.50 review assumption.

The methodology and CSV are separate so the assumptions can be changed. I would particularly value criticism of the denominator, treatment of retries, and cases where accepted-outcome cost is the wrong objective.
