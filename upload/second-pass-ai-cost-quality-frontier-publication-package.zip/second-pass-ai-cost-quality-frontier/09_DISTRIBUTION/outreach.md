# Direct outreach

## CTO / infrastructure leader

**Subject:** A break-even framework for AI model routing

I published a SECOND / PASS analysis that may be relevant to your inference/evaluation work.

Instead of ranking models by $/M tokens, it calculates the improvement in review, retry or failure rate required for a more expensive configuration to become cheaper per accepted outcome.

The piece includes the equations, a dated configuration-level price snapshot and reproducible chart data. It deliberately avoids claiming production quality from public benchmarks.

If that framing overlaps with decisions you're making, here is the research: [LINK]

— Aditya  
Founder & Editor, SECOND / PASS

## Researcher / engineer

**Subject:** Feedback on an accepted-outcome cost model for LLM routing

I put together a technical note on AI inference economics and would value criticism of the formulation.

The central move is to treat model/configuration selection as an expected-cost problem over accepted outcomes, with retries, review, failure and latency separated from direct model billing. A worked review break-even is included, plus a sequential routing formulation.

PROOF and source-level DATA are here: [LINK]

If you spot a bad assumption or a missing failure term, I would genuinely like to know.

— Aditya
