# Medium excerpt

## Title
The token bill is not the AI system cost

Publish an excerpt only:

hook → FIRST PASS → 25× / $0.0768 example → 1.71 pp calculation.

Stop before caching and routing.

Footer:

> This is an excerpt from SECOND / PASS. The canonical version contains the full methodology, dated pricing dataset, chart data and limitations.

Canonical: [FLAGSHIP URL]
