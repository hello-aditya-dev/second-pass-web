# LinkedIn — SECOND / PASS

**New / SECOND PASS**

The cheapest AI model is often not the cheapest system.

SECOND / PASS modelled inference cost around the accepted outcome rather than the provider token bill.

Key calculation:
- current GPT-5.6 Sol/Luna short-context token-rate ratio: 25×
- direct-cost difference on a nominal 10k-input/1k-output example: $0.0768
- at $4.50 per human review, break-even review reduction: 1.71 percentage points

This is a decision threshold, not a performance claim.

The release includes:
- flagship analysis
- formal PROOF
- configuration-level DATA snapshot
- reproducible chart inputs
- explicit limitations

[LINK]
