# AI Inference Price Surface v0.1

Generated: `2026-08-09T18:47:00+05:30`  
Source access date: `2026-08-09`

## Purpose
Provide a reproducible billing-input layer for SECOND / PASS analysis.

## Method
Prices were re-checked against provider-owned documentation on 2026-08-09. Rows are split when a provider exposes materially different pricing by Batch/service tier or context band.

## Coverage
- OpenAI GPT-5.6 Sol and Luna
- Anthropic Claude Opus 5 and Sonnet 5
- Google Gemini 3.6 Flash and Gemini 3.5 Flash-Lite
- Mistral Small 4
- xAI Grok 4.5

## Important temporal note
Claude Sonnet 5 has separate rows for introductory pricing through 2026-08-31 and announced standard pricing beginning 2026-09-01.

## Not included
- negotiated enterprise discounts
- measured latency
- benchmark quality
- production acceptance rates
- hardware-equivalent self-host inference cost

## Source URLs
- S1: OpenAI API Pricing — https://developers.openai.com/api/docs/pricing
- S2: OpenAI GPT-5.6 Sol — https://developers.openai.com/api/docs/models/gpt-5.6-sol
- S3: OpenAI GPT-5.6 Luna — https://developers.openai.com/api/docs/models/gpt-5.6-luna
- S4: Anthropic Claude pricing — https://docs.anthropic.com/en/docs/about-claude/pricing
- S5: Anthropic Sonnet 5 — https://docs.anthropic.com/en/docs/about-claude/models/whats-new-sonnet-5
- S6: Google Gemini pricing — https://ai.google.dev/gemini-api/docs/pricing
- S7: Mistral Small 4 — https://docs.mistral.ai/models/model-cards/mistral-small-4-0-26-03
- S8: xAI pricing — https://docs.x.ai/developers/pricing
- S9: xAI Grok 4.5 — https://docs.x.ai/developers/grok-4-5
- S10: xAI Batch API — https://docs.x.ai/developers/advanced-api-usage/batch-api
