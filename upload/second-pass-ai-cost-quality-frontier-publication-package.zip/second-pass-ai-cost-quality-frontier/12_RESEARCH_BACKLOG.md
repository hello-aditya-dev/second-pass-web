# RESEARCH_BACKLOG.md

## HIGH VALUE / NEXT

### Controlled production-quality evaluation
Run two representative workloads with task-level acceptance criteria:
1. high-volume structured classification
2. analyst/research workflow

Measure accepted rate, repair rate, retries, review incidence and review duration by configuration.

### Controlled latency measurements
Collect p50/p95/p99 TTFT and end-to-end latency using fixed regions, prompt shapes, concurrency and reasoning settings.

### Self-hosting utilization study
Use equivalent open-weight model serving benchmarks, SLO-matched throughput and explicit fleet redundancy. Obtain defensible hardware/hosting cost scenarios.

### Output-budget economics
Measure quality as a function of output budget and reasoning effort; test joint model/output decisions.

## MEDIUM VALUE

### Monte Carlo extension
Only after empirical distributions exist. Sample workload volume, token length, success, review, latency and utilization with preserved correlations.

### Failure-cost catalogue
Build organization-specific templates for false positives, false negatives, rollback, compliance review and customer escalation.

### Vendor-switching cost
Estimate integration, evaluation, prompt migration, tokenizer and observability changes.

### Additional provider configurations
Add current commercial and open-weight ecosystems only when source definitions are comparable.

## OPTIONAL

### Energy per accepted outcome
Requires measured system power and serving throughput under the same workload/SLO.

### Carbon accounting
Only after defensible energy attribution and regional electricity factors exist.

### Three-dimensional frontier visualization
Do not use 3D merely for appearance. Build only if latency observations are comparable enough to justify it.

## BLOCKED

### Universal benchmark-to-business-ROI conversion
Blocked by task mismatch and missing enterprise failure/review data.

### Universal owned-GPU purchase price
Blocked by negotiated hardware/server configuration and deployment-specific CapEx.

### Cross-provider “same prompt” cost from nominal token counts
Blocked unless the workload is tokenized or measured under each provider/model configuration.
