# Article Notes

## Editorial purpose
Move the reader from token-price comparison to accepted-outcome economics.

## Key public calculation
- GPT-5.6 Luna direct cost at 10k input / 1k output: **$0.0032**
- GPT-5.6 Sol direct cost: **$0.0800**
- incremental cost: **$0.0768**
- $4.50 review event
- break-even review-rate reduction: **1.71 pp**

## This is NOT a performance claim
Do not write or visually imply that Sol actually reduces review rate relative to Luna. Review rates in the cost-composition example are scenario assumptions.

## Recommended pull quote
> "The billing meter records tokens. The organization pays for outcomes."

## Optional social stat
`25× token price → $0.0768 absolute difference on a 10k/1k example → 1.71 pp review break-even at $4.50/review`

## Source-display rule
Render source IDs inline and provide the precise source list at article end. For volatile price claims, display snapshot date `2026-08-09`.

## Ad policy
Editorial. The `/ INTELLIGENCE` block is the only commercial connection.
