# SECOND / PASS Publication Package Manifest

## Research project
AI inference economics and model routing

## Flagship title
**The cheapest AI model is often not the cheapest system**

## Flagship slug
`cheapest-ai-model-not-cheapest-system`

## Section
AI

## Format
SECOND PASS

## Research snapshot
- Dataset version: **v0.1**
- Verified: **2026-08-09**
- Working dossier: *Optimal Routing on the AI Cost–Quality Frontier*
- Public release scope: accepted-outcome economics, review break-even, caching, Batch, configuration-level pricing, routing decision model
- Deferred: controlled cross-provider latency testing, production workload quality experiments, owned-GPU CapEx, Monte Carlo

## Files included
- `01_EDITORIAL_DECISION.md`
- `02_FLAGSHIP/cheapest-ai-model-not-cheapest-system.mdx`
- `02_FLAGSHIP/article-notes.md`
- `03_PROOF/cheapest-ai-model-not-cheapest-system-proof.mdx`
- `04_DATA/ai-inference-price-surface.mdx`
- `04_DATA/ai-inference-price-surface-v0.1.csv`
- `04_DATA/ai-inference-price-surface-v0.1.json`
- `04_DATA/DATA_DICTIONARY.md`
- `04_DATA/README.md`
- `05_CHARTS/chart-specs.md`
- five chart datasets in `05_CHARTS/data/`
- five charts as PNG + SVG
- `06_BRIEF/brief-issue.md`
- `07_FOLLOWUPS/queue.md`
- three publishable `/ NOW` drafts plus `08_NOW/now-queue.md`
- native distribution copy in `09_DISTRIBUTION/`
- social visual specifications in `10_SOCIAL/`
- source, claim, calculation and fact-check ledgers in `11_QA/`
- `12_RESEARCH_BACKLOG.md`
- `13_SITE_HANDOFF.md`

## Datasets
1. **AI Inference Price Surface v0.1** — configuration-level public list-price snapshot.
2. Five chart-specific derived datasets.

## Charts
1. Review-cost break-even curve.
2. Prompt-cache reuse break-even.
3. Standard vs Batch token-charge comparison.
4. Direct-model vs human-review cost composition.
5. Long-context pricing multipliers.

## Follow-up stories
Six high-value follow-ups are queued. Three timely `/ NOW` drafts are included.

## BRIEF
One SECOND / PASS / BRIEF issue draft is included.

## QA status
- Primary-source price verification: PASS
- Arithmetic reproduction: PASS
- Units: PASS
- Assumption labeling: PASS
- Vendor/independent evidence separation: PASS
- Volatile-data dating: PASS
- No invented benchmarks or production success rates: PASS
- Human publish gate: REQUIRED

## Known non-blocking limitations
- No controlled latency benchmark.
- No empirical workload-specific model success-rate study.
- Public list prices do not represent negotiated enterprise pricing.
- Cross-model nominal token counts are not text-equivalent because tokenizers differ.
- Self-hosting ownership economics remain a follow-up; cloud rental and hardware specifications alone are not sufficient to infer owned-fleet TCO.

# PUBLICATION PACKAGE STATUS:
READY
