# SECOND / PASS Site Handoff

## Public content

### Flagship
- **file:** `02_FLAGSHIP/cheapest-ai-model-not-cheapest-system.mdx`
- **route recommendation:** `/ai/cheapest-ai-model-not-cheapest-system/`
- **section:** AI
- **format:** SECOND PASS
- **status:** review
- **featured:** true
- **author:** Aditya
- **publisher:** SECOND / PASS

### PROOF
- **file:** `03_PROOF/cheapest-ai-model-not-cheapest-system-proof.mdx`
- **route recommendation:** `/proof/cheapest-ai-model-not-cheapest-system/`
- **relationship:** child methodology for flagship
- **status:** review

### DATA
- **file:** `04_DATA/ai-inference-price-surface.mdx`
- **route recommendation:** `/data/ai-inference-price-surface-v0-1/`
- **downloads:** CSV + JSON + data dictionary
- **snapshot badge:** `v0.1 · 2026-08-09`

### NOW drafts
Files in `08_NOW/drafts/` are public-content candidates with `status: review`.

## Internal only
Do not expose as article content:
- `01_EDITORIAL_DECISION.md`
- `02_FLAGSHIP/article-notes.md`
- `07_FOLLOWUPS/queue.md`
- `08_NOW/now-queue.md`
- `11_QA/*`
- `12_RESEARCH_BACKLOG.md`
- raw distribution planning files unless used externally

## Chart placement in flagship

1. After review break-even calculation:
   - `chart-01-review-break-even.svg` preferred; PNG fallback.
2. After illustrative model+review scenario:
   - `chart-04-cost-composition.svg`.
3. After provider configuration/context discussion:
   - `chart-05-long-context.svg`.
4. After prompt-cache calculation:
   - `chart-02-cache-reuse.svg`.
5. After Batch section:
   - `chart-03-batch-cost.svg`.

Use figure captions from `05_CHARTS/chart-specs.md`.

## Technical component usage

Use existing site components where available. Do not redesign the site.

Map house objects to existing callout primitives:
- `/ FIRST PASS` → numbered summary list.
- `/ CALCULATION` → bordered technical callout.
- `/ CLAIM CHECK` → evidence-status callout.
- `/ INTELLIGENCE` → subtle CTA.
- source IDs → source list/footnote component.
- DATA downloads → static file links.

If no dedicated component exists, render semantic MDX with minimal wrapper classes rather than adding a new component system.

## Tables

The DATA page can render a compact subset of the CSV:
`provider, model, service_tier, context_band, input, cached_input, output, effective dates`.

Do not render all internal notes on mobile by default. Allow horizontal scroll for the price table.

## Source display

- Show `Snapshot: 2026-08-09` anywhere price data appears.
- Source links must point to precise provider pages, not homepages.
- Distinguish scenario values from observed prices in captions.
- Do not imply live/current updating unless the build actually refreshes the dataset.

## Mobile

- Equations: allow horizontal overflow inside the math container, not page-level overflow.
- Charts: width 100%; use SVG where possible; PNG fallback.
- Long model names: wrap rather than shrink below legible type.
- FIRST PASS: stack bullets vertically.
- Calculation objects: preserve QUESTION / RESULT / CAVEAT order.
- Wide DATA table: contained horizontal scroll with sticky first column only if the existing table component supports it.

## Static-first implementation

No database is needed for v1.
- MDX: build-time content.
- CSV/JSON: public static downloads.
- SVG/PNG: static assets.
- Source ledger remains internal unless a source-list build step consumes it.

## Cross-links

Flagship → PROOF, DATA, BRIEF  
PROOF → Flagship, DATA  
DATA → Flagship, methodology note  
NOW pieces → Flagship or DATA when relevant

## Metadata

Keep the frontmatter supplied in each MDX. Do not add invented schema fields. `publishedAt` and `updatedAt` remain placeholders until human approval.

## Human gate

Do not change `status: review` to published without explicit human approval.
