# Social / Visual Asset Specification

Visual language: warm paper, black ink, graphite, thin rules, Signal Blue, engineering-grid logic. No decorative AI imagery.

## 1200 × 630 OG

- **kicker:** SECOND / PASS — AI
- **headline:** The cheapest AI model is often not the cheapest system
- **key stat:** `25× token rate → 1.71 pp review break-even`
- **source/method label:** `PUBLIC LIST PRICES · SNAPSHOT 2026-08-09 · SCENARIO REVIEW COST`
- **footer:** `SECOND / PASS`
- **layout:** headline left 65%; calculation block right 35%; thin rule; small source-date footer
- **alt text:** SECOND / PASS cover showing a 25× token-price gap and a 1.71 percentage-point human-review break-even threshold.

## 1080 × 1350 portrait

- **kicker:** / CALCULATION
- **headline:** How can a 25× model-price gap disappear?
- **calculation:** `$0.0800 − $0.0032 = $0.0768` then `$0.0768 / $4.50 = 1.71 pp`
- **method label:** `10k input · 1k output · short context · review = 3 min at $90/h`
- **footer:** `THRESHOLD, NOT PERFORMANCE CLAIM · SECOND / PASS`
- **alt text:** Worked break-even calculation showing that $0.0768 of extra token cost is offset by 1.71 percentage points less review when review costs $4.50.

## 1080 × 1080 square

- **kicker:** / FIRST PASS
- **headline:** Token price is the wrong denominator.
- **body:** `Measure cost / accepted outcome`
- **subline:** `tokens + retries + review + failure + latency`
- **footer:** `SECOND / PASS · AI · 2026-08-09 snapshot`
- **alt text:** Minimal typographic card defining accepted-outcome cost as model tokens plus downstream operational costs.

## 1920 × 1080 video frame

- **use:** 15–25 second motion explainer if video distribution is pursued.
- **frame 1:** `25×` large.
- **frame 2:** reveal `$0.0032 → $0.0800`.
- **frame 3:** isolate `Δ = $0.0768`.
- **frame 4:** introduce `1 review = $4.50`.
- **frame 5:** solve `0.0768 / 4.50 = 1.71 pp`.
- **end card:** `The billing meter records tokens. The organization pays for outcomes.`
- **alt/transcript:** include all displayed calculations in captions.

## Source display
Do not put provider logos in the hero. Use textual source labels in small type. The visual is about the calculation, not vendor branding.
