# Follow-up drafts

No follow-up article is promoted to a full draft in v1. Each queued story requires new evidence or a distinct analytical object before drafting; see `../queue.md`.
