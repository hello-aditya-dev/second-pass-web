# Follow-up Article Queue

| Priority | Working title | Format | Central question | Core finding / angle | Required evidence | Recommended word count | Best chart |
|---|---|---|---|---|---|---:|---|
| 1 | Prompt caching pays back faster than most teams think | SECOND PASS | When is a cached prefix actually cheaper? | A 1.25× write / 0.10× read structure has a two-use theoretical break-even; real value depends on TTL, minimum prefix length and reuse probability. | Fresh provider cache rules + real prefix-reuse traces. | 1,500–2,200 | Reuse break-even + hit-rate surface |
| 2 | What long context really costs | SECOND PASS | Is there a universal long-context premium? | No. Current price architecture differs materially by provider and configuration. | Fresh provider price snapshot + context thresholds. | 1,500–2,000 | Long-context multiplier table/curve |
| 3 | Routing is a control problem, not a model lookup | PROOF | How should multi-stage agents allocate expensive model calls? | Sequential state and terminal feedback make routing path-dependent. | RouteLLM, FrugalGPT, SeqRoute, budget-aware agentic routing + worked policy. | 2,500–3,500 | Routing state diagram |
| 4 | The utilization cliff | DEEP | When does self-hosting beat APIs? | Fixed cost per request scales roughly as 1/utilization; owned TCO needs equivalent throughput and SLO data. | MLPerf/serving benchmarks, fleet quotes, power, labor, redundancy. | 3,000–4,000 | API/self-host break-even surface |
| 5 | Output tokens are a budget variable | SECOND PASS | Should routers choose output length as well as model? | Current input/output price ratios make output control economically material; newer routing work also treats output budget as a decision variable. | Current provider prices + output-budget quality curves + routing research. | 2,000–2,800 | Quality vs output-budget frontier |
| 6 | What a benchmark point is worth | DEEP | Can benchmark improvement be mapped to enterprise ROI? | Only after measuring task-specific acceptance and failure costs; a generic conversion is invalid. | Controlled two-workload evaluation. | 2,500–3,500 | Benchmark score vs accepted-outcome scatter |

## Publication logic

Do not publish follow-ups merely to restate the flagship. Each item above introduces a new denominator, measurement problem, architecture question or dataset.
