# / NOW Queue

1. **Claude Sonnet 5 has a dated price step on September 1** — current $2/$10 introductory input/output becomes $3/$15. Information gain: price snapshots need effective dates, not only access dates. **Priority: immediate.**
2. **Prompt caching can cross break-even on the second eligible use** — under 1.25× write / 0.10× read pricing. Information gain: measure stable-prefix reuse, not generic cache enthusiasm. **Priority: high.**
3. **Long-context pricing is not portable across providers** — OpenAI GPT-5.6 and xAI Grok 4.5 expose explicit premiums while Anthropic Claude 4.6+ states its 1M context is at standard rate. **Priority: high.**
4. **Batch is a 50% price lever before changing models** — for the included OpenAI, Anthropic and Google configurations. **Priority: high.**
5. **Grok 4.5 is not currently supported by xAI Batch** — capability should be a per-model field, not inferred from provider-level API availability. **Priority: medium.**
6. **Tokenization itself can move cost** — Anthropic says its newer tokenizer can produce approximately 30% more tokens for the same text than Sonnet 4.6. **Priority: high.**
7. **OpenAI's GPT-5.6 long-context threshold is a billing cliff** — above 272k input tokens, the full request uses higher rates. **Priority: medium.**
8. **GPU rental price is not self-hosted TCO** — cloud H200 rental is observable, but throughput, utilization, redundancy and engineering determine cost per accepted request. **Priority: medium.**
