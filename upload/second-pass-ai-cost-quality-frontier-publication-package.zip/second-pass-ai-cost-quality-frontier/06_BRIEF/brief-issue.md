# SECOND / PASS / BRIEF

**ISSUE / [NUMBER]**  
**AUTHOR / Aditya — Founder & Editor**  
**STATUS / review**  
**SUBJECT / The 25× AI price gap that can disappear in 1.71 points**  
**PREHEADER / Why cost per accepted outcome is a better production denominator than $/M tokens.**

## / BRIEF [ISSUE NUMBER]

### THE DEVELOPMENT

The easiest way to misread AI inference economics is to stop at the provider price table.

Current APIs can vary by context band, cache state, Batch, service tier and reasoning mode. More importantly, production systems pay for retries, review and failure after the model bill arrives.

### 3 SIGNALS

**01 / The denominator is changing.**  
`$/M tokens` is useful for billing. `$/accepted outcome` is more useful for production decisions.

**02 / Human review can dominate tokens.**  
At current GPT-5.6 short-context prices, Sol is 25× Luna per token. On a nominal 10k-input/1k-output task that is an absolute premium of **$0.0768**.

**03 / Configuration beats model name.**  
Batch currently halves token prices for the OpenAI, Anthropic and Google configurations in our snapshot; long-context pricing behaves differently across providers.

### 1 NUMBER

# 1.71 pp

If a human review costs $4.50, reducing review incidence by **1.71 percentage points** offsets the entire $0.0768 Sol-vs-Luna token premium in our worked example.

That is a break-even threshold, not a claim about actual model performance.

### 1 CHART

Use `05_CHARTS/chart-01-review-break-even.png`.

### WHY IT MATTERS

A team choosing models from token price plus a generic benchmark score can optimize the wrong layer.

Measure direct spend, accepted rate, retries, review incidence, review duration and failure cost on the actual workload. Then route to the cheapest configuration that clears the business constraint.

### READ / SECOND PASS

**The cheapest AI model is often not the cheapest system**

### INSPECT / PROOF

**How to model the cost of an accepted AI outcome**

### EXPLORE / DATA

**AI Inference Price Surface v0.1 — snapshot 2026-08-09**
