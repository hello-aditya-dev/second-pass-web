# Chart Specifications

All charts use observed prices where noted and clearly labelled scenario assumptions otherwise.

## chart-01-review-break-even

- **title:** How much review reduction pays for the 25× token-price gap?
- **decision_question:** How much must a more expensive configuration reduce human review to offset its direct token premium?
- **chart_type:** line / break-even curve
- **x_axis:** cost of one human review, USD
- **y_axis:** required review-rate reduction, percentage points
- **series:** GPT-5.6 Sol vs Luna worked example
- **data fields:** `review_cost_usd`, `required_review_rate_reduction_pp`
- **formula:** `100 * 0.0768 / review_cost_usd`
- **source basis:** S1–S3 for token prices; review cost is a scenario variable
- **main takeaway:** At a $4.50 review event, 1.71 pp of avoided review pays for the $0.0768 token premium.
- **caveats:** Does not claim actual review-rate differences.
- **alt text:** Break-even curve showing required review-rate reduction declining as the cost of human review rises; the marked $4.50 review cost requires a 1.71 percentage-point reduction.
- **mobile behavior:** full-width; preserve annotation; no horizontal scroll.

## chart-02-cache-reuse

- **title:** Prompt caching can pay back after two or three eligible uses
- **decision_question:** How many stable-prefix reuses are needed before caching is cheaper?
- **chart_type:** line
- **x_axis:** eligible prefix uses
- **y_axis:** normalized input cost
- **series:** uncached; 1.25× write + 0.10× reads; 2× write + 0.10× reads
- **data fields:** chart CSV
- **source basis:** S1 and S4 multipliers
- **main takeaway:** theoretical integer break-even is use 2 for 1.25× writes, use 3 for 2× writes.
- **caveats:** TTL, minimum prefix size and hit probability are excluded.
- **alt text:** Three cost lines; uncached rises one unit per use while cached lines rise slowly after an upfront write cost.
- **mobile behavior:** full-width with compact legend.

## chart-03-batch-cost

- **title:** For eligible asynchronous work, Batch halves token charges here
- **decision_question:** How large is the billing change from moving the same configuration to Batch?
- **chart_type:** grouped bar, log y-axis
- **x_axis:** model configuration
- **y_axis:** USD per nominal 10k-input / 1k-output request
- **series:** Standard, Batch
- **data fields:** input/output prices and nominal tokens
- **source basis:** S1, S4, S6
- **main takeaway:** each included provider/configuration publishes a 50% Standard-to-Batch token-price reduction.
- **caveats:** same nominal token counts are not text-equivalent across tokenizers; Batch has latency/eligibility constraints; Sonnet 5 uses introductory pricing through Aug 31.
- **alt text:** Paired bars for six configurations showing every Batch bar at half the corresponding Standard bar.
- **mobile behavior:** horizontally scroll labels if needed; preserve log-axis label.

## chart-04-cost-composition

- **title:** A more expensive model can be a cheaper system
- **decision_question:** Can human review reverse the direct token-cost ranking?
- **chart_type:** stacked bars
- **x_axis:** configuration
- **y_axis:** illustrative USD/task
- **series:** direct model cost; review cost
- **observed values:** direct prices from S1
- **scenario values:** Luna review rate 10%, Sol 5%, $4.50/review
- **main takeaway:** under the stated assumptions, totals are $0.4532 vs $0.3050.
- **caveats:** review rates are not measured results.
- **alt text:** Stacked bars showing Luna's lower token cost but higher assumed review cost, resulting in a higher total than Sol.
- **mobile behavior:** full-width; labels above bars.

## chart-05-long-context

- **title:** There is no universal long-context premium
- **decision_question:** Does long context have one portable price multiplier?
- **chart_type:** grouped bars
- **x_axis:** provider configuration
- **y_axis:** long/standard per-token price multiplier
- **series:** input, output
- **source basis:** S1/S2, S4, S8
- **main takeaway:** OpenAI and xAI apply explicit long-context price multipliers in these configurations; Anthropic states Claude 4.6+ includes the full 1M context at standard pricing.
- **caveats:** thresholds differ; this is price architecture, not a quality comparison.
- **alt text:** Bars show OpenAI input at 2× and output at 1.5×, xAI input/output at 2×, and Anthropic at 1×.
- **mobile behavior:** full-width; wrap provider labels.
