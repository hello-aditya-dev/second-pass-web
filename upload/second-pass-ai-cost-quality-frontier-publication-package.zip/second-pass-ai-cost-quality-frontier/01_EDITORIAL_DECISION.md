# Editorial Decision

## The real contribution

The dossier begins as a broad study of the AI cost–quality frontier. The strongest publishable first release is narrower:

> **The economically correct unit for production AI is not dollars per million tokens. It is the expected cost of an accepted outcome.**

This reframing becomes useful when it produces a decision threshold rather than a slogan.

Using current OpenAI GPT-5.6 short-context list prices, Sol is 25× Luna on both input and output token rates. For an illustrative 10,000-input / 1,000-output task:

- Luna direct token cost: **$0.0032**
- Sol direct token cost: **$0.0800**
- incremental Sol spend: **$0.0768**

If one human review costs **$4.50** — three minutes at a loaded $90/hour — the more expensive model needs to reduce review incidence by only:

`$0.0768 / $4.50 = 0.01707`

or **1.71 percentage points** to offset its entire token-price premium.

That is an original SECOND / PASS calculation. It does **not** assert that Sol actually reduces review by 1.71 points. It establishes the threshold an organization should measure.

## Why this is stronger than a model leaderboard

A leaderboard would require a common task distribution, evaluation harness, tokenization, reasoning settings, latency regime and acceptance definition. The available public evidence does not provide that.

The current price surface itself shows why model-level comparison is underspecified:

- OpenAI changes prices across short/long context, Batch and Fast mode.
- Anthropic exposes standard, cache-write, cache-hit, Batch and Fast pricing and has a scheduled Sonnet 5 price change.
- Google exposes Standard, Batch, Flex, Priority, context caching and cache storage.
- xAI applies separate long-context pricing and does not currently support Grok 4.5 in Batch.
- Anthropic documents a tokenizer change that can produce approximately 30% more tokens for the same text on newer models.

The relevant object is therefore a **model configuration**, not a model name.

## Editorial scope for v1

### Publish now
1. Accepted-outcome denominator.
2. Human-review break-even calculation.
3. Retry-adjusted cost framework.
4. Prompt-caching break-even.
5. Batch economics.
6. Context-band/configuration effects.
7. A sequential routing decision model.
8. Configuration-level public price snapshot.

### Defer
1. Cross-provider quality ranking.
2. Controlled p50/p95/p99 latency measurements.
3. Monte Carlo simulation.
4. Owned-GPU CapEx break-even.
5. Energy per request.
6. Vendor-switching cost model.

These are valuable but not necessary to prove the v1 contribution.

## Public headline

**The cheapest AI model is often not the cheapest system**

Alternative retained for distribution tests:

**A 25× model-price gap can disappear in 1.7 percentage points**

## Reader action

After reading, a CTO should change the evaluation sheet from:

`model → $/M tokens → benchmark score`

to:

`configuration → task success → retries → review → failure → latency → accepted-outcome cost`

and measure the few parameters capable of flipping the decision.

## Original SECOND / PASS elements

- Accepted-outcome cost framing.
- Review-incidence break-even equation.
- Configuration-level price normalization.
- Cache-reuse threshold calculations.
- Progressive routing policy from deterministic/cache paths through model escalation and human review.
- Explicit separation of observed prices from scenario quality assumptions.
