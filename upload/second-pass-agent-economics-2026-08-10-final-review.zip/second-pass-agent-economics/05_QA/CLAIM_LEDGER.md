# CLAIM LEDGER

| claim_id | claim | type | evidence | confidence | caveat | publication_safe |
|---|---|---|---|---|---|---|
| CL-001 | A token rate is not a complete cost model for all tool-using agent tasks. | INFERENCE | OAI-PRICING, ANT-PRICING, GOO-PRICING, XAI-PRICING | High | Some workloads can still be token-dominated. | YES |
| CL-002 | The reviewed billing structures can be normalized into four base meter families: token volume, calls/invocations, runtime, and stored state. | INFERENCE / ORIGINAL TAXONOMY | 41-row meter dataset | High | Economic taxonomy; not feature equivalence. | YES |
| CL-003 | Configuration modifiers and inclusion/applicability rules are pricing-rule layers, not necessarily independent additive meters. | INFERENCE / ORIGINAL TAXONOMY | provider pricing structures | High | Exact rules are provider/product specific. | YES |
| CL-004 | OpenAI web search can include a per-call fee plus search-content tokens billed at model rates. | FACT | OAI-PRICING | High | Search variants can have distinct rules; article uses current documented rule in reviewed scope. | YES |
| CL-005 | OpenAI File Search exposes distinct tool-call and storage charging components. | FACT | OAI-PRICING | High | Free storage allowance applies. | YES |
| CL-006 | Anthropic web search is $10/1,000 searches plus standard token costs for search-generated content. | FACT | ANT-PRICING | High | Search accounting is provider-specific. | YES |
| CL-007 | Claude Managed Agents are billed on tokens and running-session time; web search inside a session retains its standard per-search charge. | FACT | ANT-PRICING | High | Actual quantities are workload-dependent. | YES |
| CL-008 | Managed Agents runtime is $0.08/session-hour and replaces separate Code Execution container-hour billing. | FACT | ANT-PRICING | High | Applies specifically to Managed Agents. | YES |
| CL-009 | Messages API Batch discount, Fast-mode premium, and `inference_geo` data-residency multiplier do not apply to Claude Managed Agents sessions. | FACT / PRODUCT RULE | ANT-PRICING, reverified 2026-08-10 | High | Prompt-caching multipliers still apply. | YES |
| CL-010 | Claude Haiku 4.5 standard input/output list prices are $1/$5 per million tokens. | FACT | ANT-PRICING | High | Public list price; cache pricing differs. | YES |
| CL-011 | The illustrative Managed Agents trace costs $0.0653. | CALCULATION / SCENARIO | ANT-PRICING + worked-scenario CSV | High arithmetic | Usage quantities are assumed. | YES |
| CL-012 | In the illustrative trace, search costs $0.0300, model tokens $0.0220, and runtime $0.0133. | CALCULATION / SCENARIO | CALC-001 | High arithmetic | Scenario-specific. | YES |
| CL-013 | With model tokens and runtime fixed, the third search makes search the largest individual meter. | CALCULATION / SCENARIO | CALC-002 | High arithmetic | Largest individual meter is not the same as >50% of total. | YES |
| CL-014 | One $0.01 Anthropic search equals 10,000 Haiku input tokens, 2,000 output tokens, or 7.5 running minutes at stated list prices. | CALCULATION | CALC-003 | High arithmetic | Billing equivalence only. | YES |
| CL-015 | Google Gemini Code Execution has no separate session-runtime fee in the reviewed paid API pricing; generated code/results are accounted through tokens. | FACT | GOO-PRICING, GOO-CODE | High | Exact token use depends on iteration. | YES |
| CL-016 | Google Managed Agents environment compute is currently unbilled during preview. | FACT / TEMPORAL | GOO-PRICING | High | Preview condition can change. | YES |
| CL-017 | xAI lists fixed invocation charges for several server-side tools alongside token usage, while Remote MCP has no fixed invocation fee. | FACT | XAI-PRICING | High | Do not generalize the fixed-fee rule to every xAI tool. | YES |
| CL-018 | Anthropic Managed Agents are cheaper than OpenAI, Google, or xAI agents. | UNKNOWN / UNSUPPORTED | No equivalent workload | None | Provider products are not equivalent. | NO |
| CL-019 | Three searches are typical for an agent task. | UNKNOWN / UNSUPPORTED | No production trace dataset | None | Three is a scenario quantity. | NO |
| CL-020 | Tokens no longer matter economically. | OVERBROAD INFERENCE | Contradicted by the reviewed bills | Low | Tokens remain a base meter and can dominate. | NO |
| CL-021 | Google's preview-zero managed environment compute will remain unbilled. | UNKNOWN / FUTURE | Preview rule only | None | Preview pricing can change. | NO |
