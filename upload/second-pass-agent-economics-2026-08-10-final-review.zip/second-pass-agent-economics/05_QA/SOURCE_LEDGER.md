# SOURCE LEDGER

All volatile pricing was re-checked on **2026-08-10**.

| source_id | provider / organization | document title | URL | source type | accessed_at | effective date | claims supported | limitations |
|---|---|---|---|---|---|---|---|---|
| OAI-PRICING | OpenAI | API Pricing | https://developers.openai.com/api/docs/pricing | primary | 2026-08-10 | current as documented | GPT-5.6 rates; web-search call + search-content token charging; container prices/minimum; File Search call/storage; ChatKit storage; regional uplift; service tiers | Public list price; does not represent negotiated enterprise pricing or task quality |
| ANT-PRICING | Anthropic | Claude Platform Pricing | https://platform.claude.com/docs/en/about-claude/pricing | primary | 2026-08-10 | current as documented | Haiku 4.5 token/cache prices; web search; web fetch; tool token overhead; Managed Agents tokens/runtime; runtime replacement rule; Batch/Fast/residency modifiers | Public list price; actual session usage is workload-dependent. Pricing page reverified 2026-08-10 for Managed Agents modifier exclusions |
| ANT-CODE | Anthropic | Code execution tool | https://platform.claude.com/docs/en/agents-and-tools/tool-use/code-execution-tool | primary | 2026-08-10 | current as documented | Standalone code-execution free condition, 1,550 free hours/month, $0.05/container-hour after allowance, 5-minute minimum | Standalone tool rules differ from Managed Agents runtime rules |
| GOO-PRICING | Google | Gemini Developer API pricing | https://ai.google.dev/gemini-api/docs/pricing | primary | 2026-08-10 | current as documented | Gemini 3.5 Flash-Lite rates; thinking included in output; Search grounding; context caching/storage; code execution pricing; File Search; managed-agent preview compute; service tiers | Free allowances/preview terms can change; provider-specific tool semantics |
| GOO-CODE | Google | Code execution | https://ai.google.dev/gemini-api/docs/code-execution | primary | 2026-08-10 | current as documented | Intermediate code/result token accounting in iterative code execution | Does not establish task quality or typical token volume |
| GOO-FILE | Google | File Search | https://ai.google.dev/gemini-api/docs/file-search | primary | 2026-08-10 | current as documented | File Search mechanism and retrieved-context use | Pricing authority remains the main pricing page |
| XAI-PRICING | xAI | Pricing | https://docs.x.ai/developers/pricing | primary | 2026-08-10 | page notes last updated 2026-07-03 | Grok 4.5 token rates; fixed server-tool call prices; Priority; Batch rule; storage/download prices; MCP token-only rule | Public list price; model availability and tool support can change |
| XAI-TOOLS | xAI | Tools Overview | https://docs.x.ai/developers/tools/overview | primary | 2026-08-10 | current as documented | Tool names and Responses API tool combinations | Functional documentation; pricing authority is XAI-PRICING |

## Evidence use rule

The article uses provider documentation to establish provider billing. It does not use one provider to state another provider's price.

No benchmark source is needed because this release does not compare model quality.
