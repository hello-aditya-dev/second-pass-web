# CALCULATION LEDGER

## CALC-001 — Worked agent-task cost

**Question**  
What does the illustrative Claude Managed Agents + Haiku 4.5 task cost?

**Inputs**
- 12,000 cumulative input tokens — ASSUMPTION
- 2,000 cumulative output tokens — ASSUMPTION
- 3 web searches — ASSUMPTION
- 10 running minutes — ASSUMPTION
- Haiku 4.5 input price: $1/MTok — FACT, ANT-PRICING
- Haiku 4.5 output price: $5/MTok — FACT, ANT-PRICING
- web search: $10/1,000 — FACT, ANT-PRICING
- Managed Agent runtime: $0.08/session-hour — FACT, ANT-PRICING

**Units**
tokens, searches, minutes, USD

**Formula**
`input + output + search + runtime`

**Substitution**
- input: `12,000 / 1,000,000 × $1 = $0.0120`
- output: `2,000 / 1,000,000 × $5 = $0.0100`
- search: `3 / 1,000 × $10 = $0.0300`
- runtime: `10 / 60 × $0.08 = $0.013333...`

**Result**
`$0.0120 + $0.0100 + $0.0300 + $0.013333... = $0.065333...`

Published rounding: **$0.0653**

**Assumptions**
No prompt cache and no retry. Managed Agents pricing rules exclude the Messages API Batch discount, Fast-mode premium, and `inference_geo` data-residency multiplier; those are not scenario assumptions.

**Interpretation**
The scenario crosses token, call and runtime meters in one task.

**Limitations**
Not a typical or observed trace. Search-result content is included in the cumulative input-token assumption and is not added separately.

---

## CALC-002 — Search dominance threshold

**Question**  
How many searches make search cost larger than each other fixed individual cost category?

**Inputs**
- model-token category: $0.0220
- runtime category: $0.013333...
- search: $0.01 per search

**Formula**
`0.01 × n > max(0.0220, 0.013333...)`

**Substitution**
`0.01n > 0.022`

`n > 2.2`

**Result**
First whole search count satisfying the inequality: **3**. This makes search the largest individual meter; it does not make search more than half of total cost.

**Rounding**
No rounding in threshold decision; integer ceiling after inequality.

**Interpretation**
At 0–2 searches, model tokens remain the largest category in this scenario. At 3 searches, search becomes larger.

**Limitations**
This threshold changes with model, token count, runtime, search price, cache use or service modifiers.

---

## CALC-003 — One-search billing equivalences

**Question**  
What other Haiku Managed-Agent meters equal one $0.01 web-search invocation in current list-price terms?

### Input tokens
`$0.01 / ($1 / 1,000,000) = 10,000 tokens`

### Output tokens
`$0.01 / ($5 / 1,000,000) = 2,000 tokens`

### Runtime
Runtime per minute:
`$0.08 / 60 = $0.001333...`

`$0.01 / $0.001333... = 7.5 minutes`

**Result**
One search equals:
- **10,000 input tokens**
- **2,000 output tokens**
- **7.5 running minutes**

**Interpretation**
These values show the scale of a fixed call fee relative to other meters.

**Limitations**
Billing equivalence only. It does not imply equivalent quality, information value, latency or work.

---

## CALC-004 — Scenario scaling

No volume discount is assumed.

| Tasks | Model tokens | Search | Runtime | Total |
|---:|---:|---:|---:|---:|
| 1 | $0.0220 | $0.0300 | $0.013333 | $0.065333 |
| 1,000 | $22.00 | $30.00 | $13.333 | $65.333 |
| 100,000 | $2,200.00 | $3,000.00 | $1,333.333 | $6,533.333 |
| 1,000,000 | $22,000.00 | $30,000.00 | $13,333.333 | $65,333.333 |

**Interpretation**
A one-cent per-task meter is $10,000 per one million identical tasks.

**Limitations**
Scenario scaling only; no claim that these task volumes or discounts apply to a specific company.

---

## CALC-005 — Cost shares in worked trace

Total: `$0.065333...`

- input: `$0.012 / total = 18.37%`
- output: `$0.010 / total = 15.31%`
- all model tokens: `$0.022 / total = 33.67%`
- search: `$0.030 / total = 45.92%`
- runtime: `$0.013333... / total = 20.41%`

The public article uses absolute money as the primary presentation and does not rely on these percentages for its thesis.
