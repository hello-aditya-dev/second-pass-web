# BRIEF Summary

## Summary

Token rates still matter, but an agent task can cross four base meter families: token volume, calls, runtime, and stored state. Configuration and inclusion rules sit above those meters and change what is charged. In one illustrative Claude Managed Agents trace, 12,000 input tokens, 2,000 output tokens, three searches, and 10 running minutes cost $0.0653. Search is the largest individual line at $0.0300. With model-token and runtime quantities fixed, the third search is the first point where search overtakes the $0.0220 model-token cost.

## Key number
**3 searches** — the break-even in the fixed illustrative trace, not a universal agent rule.

## Chart recommendation
`chart-04-sensitivity.svg` — shows search overtaking model-token spend at the third search.

## Suggested link label
**READ / PRICE THE AGENT PATH →**
