# Social Asset Copy

SECOND / PASS visual system:
- Paper `#F2EFE7`
- Ink `#11110F`
- Graphite `#5A5953`
- Rule `#C9C3B7`
- Signal Blue `#2F5BFF`
- no gradients
- no stock imagery
- no robot or generic AI-brain imagery

## Primary 1200 × 630 OG

**Kicker**  
SECOND / PASS  
AI / SECOND PASS

**Headline**  
TOKEN PRICE  
DOESN'T TELL YOU  
WHAT AN AI AGENT COSTS

**Supporting line**  
TOKENS / CALLS / RUNTIME / STORED STATE

**Method line**  
PRIMARY SOURCES / ORIGINAL CALCULATIONS / 2026-08-10

Do not put `3 searches` or `$0.0653` on the primary OG. Both belong to one illustrative provider-specific trace.

**Alt text**  
SECOND / PASS research cover stating that token price does not tell the full cost of an AI agent, with four base meter families: tokens, calls, runtime and stored state.

## 1080 × 1350 Calculation Card

**Kicker**  
/ ILLUSTRATIVE WORKLOAD

**Headline**  
ONE AGENT TASK  
THREE BASE METERS

**Main calculation**  
MODEL TOKENS  $0.0220  
WEB SEARCH    $0.0300  
RUNTIME       $0.0133  
────────────  
TOTAL         $0.0653

**Context**  
CLAUDE MANAGED AGENTS + HAIKU 4.5  
12K INPUT / 2K OUTPUT / 3 SEARCHES / 10 RUNNING MIN

**Safety line**  
SCENARIO QUANTITIES / CURRENT PUBLIC LIST PRICES

**Alt text**  
Illustrative Managed Agents cost stack: 2.20 cents model tokens, 3.00 cents web search and 1.33 cents runtime, totaling 6.53 cents.

## 1080 × 1080 Break-even Card

**Kicker**  
/ CALCULATION

**Headline**  
WHEN DOES SEARCH  
BECOME THE LARGEST LINE?

**Body**  
MODEL TOKENS = 2.20¢  
SEARCH = 1.00¢ × N  
`N > 2.2`

**Result**  
**3 SEARCHES**

**Context**  
LARGEST INDIVIDUAL METER / FIXED WORKED TRACE

**Footer**  
SECOND / PASS · SCENARIO THRESHOLD

**Alt text**  
Break-even card showing that three one-cent searches exceed a fixed 2.20-cent model-token line in the article's illustrative trace.

## Optional 1920 × 1080 Video Frame Sequence

1. `MODEL → ANSWER`
2. Expand to `MODEL → SEARCH → MODEL → TOOL → MODEL → ANSWER`
3. Label the base meters: tokens / calls / runtime / stored state.
4. Add a second layer: configuration + applicability rules.
5. Reveal `2.20¢ tokens / 3.00¢ search / 1.33¢ runtime`.
6. End: `PRICE THE PATH, NOT ONLY THE MODEL.`

Keep `ILLUSTRATIVE WORKLOAD` visible whenever the $0.0653 or 3-search result appears.
