# SECOND / PASS — Agent Economics Publication Package

## Research project
What does an AI agent actually cost when the model call is only one component of the bill?

## Final headline
**Token price no longer tells you what an AI agent costs**

## Canonical slug
`an-ai-agent-is-no-longer-priced-in-tokens`

## Publication
SECOND / PASS

## Format
SECOND PASS

## Section
AI

## Author
Aditya

## Target publication date
2026-08-10

## Package contents

### Public-safe
- `02_ARTICLE/an-ai-agent-is-no-longer-priced-in-tokens.md`
- `03_RESEARCH/agent-billing-meters-2026-08-10.csv`
- `03_RESEARCH/agent-billing-meters-2026-08-10.json`
- `03_RESEARCH/agent-cost-worked-scenario.csv`
- four PNG charts
- four SVG charts
- four chart-data CSV files
- `08_BRIEF/brief-summary.md`

### Internal / production
- editorial decision
- source ledger
- claim ledger
- calculation ledger
- double-counting and adversarial fact check
- publication gate
- distribution package
- social asset copy
- follow-up extractions
- site handoff

## Worked scenario
Provider/configuration: Anthropic Claude Managed Agents + Claude Haiku 4.5, Claude Platform direct pricing.

Illustrative workload:
- 12,000 cumulative input tokens
- 2,000 cumulative output tokens
- 3 web searches
- 10 minutes of session status `running`
- no prompt cache
- no retry

Managed Agents pricing rules verified 2026-08-10:
- Messages API Batch discount does not apply
- Fast-mode premium does not apply
- `inference_geo` data-residency multiplier does not apply
- prompt-caching multipliers do apply


Calculated cost:
- model tokens: $0.0220
- search: $0.0300
- runtime: $0.0133
- total: **$0.0653**

The quantities are scenario assumptions. The prices are current public list prices verified on 2026-08-10.

## Central result
With model-token cost fixed at $0.0220 and session runtime fixed at $0.0133, Anthropic web search at $0.01 per search becomes the dominant cost category on the **third search**.

One $0.01 search invocation is also equal in list-price terms to:
- 10,000 Haiku 4.5 input tokens;
- 2,000 Haiku 4.5 output tokens; or
- 7.5 minutes of Managed Agent running time.

These are billing equivalences, not performance equivalences.

## Charts
1. Agent billing path
2. Worked cost composition
3. Provider base-meter + pricing-rule matrix
4. Search-count sensitivity

## QA
Primary-source verification: PASS  
Double-counting audit: PASS  
Calculation reproduction: PASS  
Article status: `review`  
Human publish gate: REQUIRED
Pangram prose audit: NEXT

## Known limitations
- No claim about a “typical” agent trace.
- No cross-provider cheapest-agent ranking.
- Public list prices may differ from negotiated enterprise prices.
- Preview and free-allowance rules can change.
- Tool-result token volume is workload-specific.
- Latency and model quality are outside this article's scope.

# PUBLICATION PACKAGE STATUS
READY FOR PANGRAM + HUMAN REVIEW
