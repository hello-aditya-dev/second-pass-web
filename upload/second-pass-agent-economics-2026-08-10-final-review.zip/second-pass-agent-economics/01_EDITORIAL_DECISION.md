# Editorial Decision

## Final headline

**Token price no longer tells you what an AI agent costs**

The headline remains. It is precise: token pricing still matters, but a token rate alone does not price every billable step in a tool-using agent workflow.

## Final conceptual framework

The earlier draft treated six items as peer billing shapes. The final framework separates **four base meter families** from **two rule layers**.

### Base meter families
1. Token volume
2. Calls / invocations
3. Runtime
4. Stored state

### Pricing and applicability layers
- **Configuration modifiers** change a meter's unit price or pricing function: Batch, Flex, Fast/Priority, context bands, region/data residency where applicable.
- **Inclusion / allowance / applicability rules** determine whether and how a meter applies: free allowances, preview-period zero pricing, minimum durations, product exclusions, or one charge replacing another.

The general model is:

$$
C_{\text{agent}}=\sum_m q_m p_m(a)
$$

`m` is a provider-defined billable meter, `q_m` is measured usage, `a` is the active configuration, and `p_m(a)` is the applicable price. Inclusion and applicability rules determine whether a term is billed.

This avoids the earlier conceptual mistake of treating configuration as an independent additive cost.

## Confirmed factual correction

Anthropic's current pricing documentation states that the Messages API Batch discount, Fast-mode premium, and data-residency multiplier through `inference_geo` do not apply to Claude Managed Agents sessions. They are therefore **product/pricing rules**, not scenario assumptions.

The worked scenario now assumes only the workload quantities, no prompt cache, and no retry. It does not describe Managed Agents Batch/Fast/data-residency settings as optional switches.

## Worked calculation

Preserved without numerical changes:
- model tokens: $0.0220
- web search: $0.0300
- session runtime: $0.0133
- total: $0.0653
- search becomes the largest individual meter at 3 searches
- one $0.01 search equals 10,000 Haiku 4.5 input tokens, 2,000 output tokens, or 7.5 running minutes at the stated prices

## Editorial changes

The final article:
- opens with the accounting problem faster;
- removes the repeated "some providers..." rhythm;
- makes the four-meter taxonomy the main intellectual object;
- moves configuration and inclusion into rule layers;
- distinguishes "largest individual meter" from "more than half of total";
- tightens provider sections around product boundaries rather than parallel comparison prose;
- replaces the generic final recap with a short engineering decision rule;
- removes the prepublication `published` change-log event.

The research scope remains unchanged.
