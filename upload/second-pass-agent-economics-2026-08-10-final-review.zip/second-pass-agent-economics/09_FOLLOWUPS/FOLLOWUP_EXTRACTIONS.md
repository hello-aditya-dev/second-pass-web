# FOLLOW-UP EXTRACTIONS

These are independent NOW candidates produced by the research. They are not full drafts.

## 01 — OpenAI web search has two meters, not one
- **central finding:** Current OpenAI web search can charge the search call and the search-content tokens sent to the model.
- **source:** OpenAI API Pricing.
- **original calculation:** For a selected model, calculate how many search-content input tokens make the token portion exceed the $0.01 call fee.
- **additional verification:** Confirm the exact search variant/model because preview/non-reasoning rules differ.
- **priority:** HIGH

## 02 — A five-minute minimum can matter more than container runtime
- **headline:** The container ran for 30 seconds. The bill may not.
- **central finding:** OpenAI says eligible container sessions are billed by the minute with a five-minute minimum.
- **source:** OpenAI API Pricing.
- **original calculation:** Compare very short tool jobs against the five-minute floor by container size.
- **additional verification:** Check session reuse semantics for the exact Hosted Shell / Code Interpreter path before publishing.
- **priority:** HIGH

## 03 — Anthropic Managed Agents replaces one runtime meter with another
- **headline:** Do not add two container bills to one Claude Managed Agent session
- **central finding:** Managed Agent session runtime is $0.08/running hour and replaces separate code-execution container-hour billing.
- **source:** Anthropic Claude Platform Pricing.
- **original calculation:** Compare repeated short sessions with one reused session if the API lifecycle makes that comparison valid.
- **additional verification:** Verify session lifecycle/reuse documentation.
- **priority:** HIGH

## 04 — Google agent sandbox compute is zero-priced only during preview
- **headline:** Free agent runtime can be a preview rule, not an architecture fact
- **central finding:** Google currently says Managed Agents environment compute is not billed during preview, while model inference/tools remain billable.
- **source:** Gemini Developer API Pricing.
- **original calculation:** Scenario showing how a future non-zero runtime price would alter a token-dominated trace.
- **additional verification:** Recheck pricing immediately before publication because preview terms can change.
- **priority:** HIGH

## 05 — One Gemini prompt can create more than one billable search query
- **headline:** One prompt does not always mean one search charge
- **central finding:** Google says a customer request can result in one or more Google Search queries and charges each performed query under the current Gemini 3 rule.
- **source:** Gemini Developer API Pricing.
- **original calculation:** Sensitivity by 1–N search queries for a fixed token workload.
- **additional verification:** Confirm how query counts appear in usage telemetry.
- **priority:** HIGH

## 06 — xAI prices code execution by call, not runtime hour
- **headline:** The same tool can have a different economic unit
- **central finding:** xAI currently lists code execution at $5/1,000 calls, while other providers can meter execution through runtime or tokens.
- **source:** xAI Pricing.
- **original calculation:** Compare call-count sensitivity against an equivalent fixed token workload without claiming provider equivalence.
- **additional verification:** Verify code tool support and any returned-token accounting for the chosen model.
- **priority:** MEDIUM

## 07 — Service tier can change the bill without changing the task text
- **headline:** Service tier is part of the agent cost function
- **central finding:** Provider APIs expose different price/scheduling modifiers. For Claude Managed Agents specifically, Anthropic documents that Messages API Batch, Fast-mode and `inference_geo` modifiers do not apply; other Anthropic API paths have their own modifier rules. xAI Priority and Gemini service tiers remain separate provider-specific examples.
- **source:** provider pricing pages.
- **original calculation:** Same fixed token workload across service tiers within one provider.
- **additional verification:** Recheck exact service guarantees and eligible models.
- **priority:** MEDIUM

## 08 — Storage is the slow meter agents can forget
- **headline:** Your agent stopped running. Its files may still be billing.
- **central finding:** OpenAI and xAI expose file/storage prices in GB-day/GiB-day; Google context caching uses token-hours.
- **source:** provider pricing pages.
- **original calculation:** Break-even between retaining state and recreating/re-uploading it for one specific provider.
- **additional verification:** Establish deletion/retention lifecycle and free allowances for the selected product.
- **priority:** MEDIUM

## 09 — Remote MCP can be a token meter instead of a tool-call meter
- **headline:** A tool call does not always have a tool-call price
- **central finding:** xAI says Remote MCP has no fixed invocation fee; token usage is still billed.
- **source:** xAI Pricing.
- **original calculation:** Compare schema/result token overhead against a fixed-call server tool inside xAI only.
- **additional verification:** Measure an actual MCP tool schema/result size.
- **priority:** MEDIUM
