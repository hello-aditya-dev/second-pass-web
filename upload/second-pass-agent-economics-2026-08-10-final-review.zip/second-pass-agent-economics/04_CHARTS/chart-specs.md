# Chart Specifications

Visual system:
- Paper `#F2EFE7`
- Ink `#11110F`
- Graphite `#5A5953`
- Rule `#C9C3B7`
- Signal Blue `#2F5BFF`
- no gradients
- no decorative AI imagery

## chart-01-agent-billing-path
- **title:** Where does an agent incur cost?
- **decision_question:** Which steps in an agent path can touch separate billable meters?
- **chart_type:** annotated process diagram
- **data:** `data/chart-01-agent-billing-path.csv`
- **unit:** categorical
- **source_basis:** provider billing structures from official pricing/tool pages; workflow path is illustrative
- **observed_vs_assumed:** meter types are evidence-derived; path is illustrative
- **main_takeaway:** `$ / million tokens` describes only the token-billed parts of a tool-using agent path.
- **caveat:** not every provider separately bills every step.
- **alt_text:** A vertical agent workflow shows user request, model, search, model, tool or runtime, model or verify, and answer, with billing notes beside the steps.
- **mobile_behavior:** full-width; keep nodes stacked vertically; do not shrink annotation text below normal caption size.

## chart-02-cost-waterfall
- **title:** Search is the largest individual meter in this worked trace
- **decision_question:** What does the illustrative Managed Agents task cost by base meter?
- **chart_type:** component bars with total reference line
- **data:** `data/chart-02-cost-waterfall.csv`
- **unit:** USD/task
- **source_basis:** Anthropic public prices checked 2026-08-10; scenario quantities defined in article
- **observed_vs_assumed:** prices observed; quantities assumed
- **annotation:** total `$0.0653`
- **main_takeaway:** search `$0.0300` > model tokens `$0.0220` > runtime `$0.0133`.
- **caveat:** search is the largest individual meter, not more than half of total cost; workload is illustrative.
- **alt_text:** Three bars show $0.0220 model tokens, $0.0300 web search, and $0.0133 session runtime, with a total of $0.0653.
- **mobile_behavior:** full-width; retain values above bars; do not rotate labels.

## chart-03-meter-matrix
- **title:** Four base meter families; configuration and inclusion sit above them
- **decision_question:** Which base meter families appear in the reviewed provider stacks, and which separate rule layers affect pricing?
- **chart_type:** categorical matrix with semantic separator
- **data:** `data/chart-03-meter-matrix.csv`
- **unit:** status
- **series:** OpenAI, Anthropic, Google, xAI
- **source_basis:** official provider pricing/tool documentation
- **observed_vs_assumed:** evidence-derived taxonomy
- **main_takeaway:** token volume, calls, runtime, and stored state are base meter families; configuration modifiers and applicability rules change how those meters are priced or whether they apply.
- **caveat:** presence does not imply feature, model-quality, or overall provider-economics equivalence. A dash means no separately paid base meter was established in the reviewed scope, not that the provider can never use that resource.
- **alt_text:** Matrix with four base meter columns—token volume, calls, runtime, stored state—followed by a visual divider and two pricing-rule columns for configuration modifiers and inclusion or applicability rules.
- **mobile_behavior:** bounded horizontal scroll at 375–430px; keep caption outside the scroll region.

## chart-04-sensitivity
- **title:** Search overtakes model-token spend at the third search
- **decision_question:** How many searches make search the largest individual meter under the worked trace's fixed model-token and runtime assumptions?
- **chart_type:** line sensitivity
- **data:** `data/chart-04-sensitivity.csv`
- **unit:** USD/task
- **x_axis:** searches per illustrative task
- **y_axis:** USD/task
- **source_basis:** Anthropic public list prices + worked-scenario assumptions
- **observed_vs_assumed:** prices observed; search count is scenario sensitivity
- **annotation:** third search becomes the largest individual meter
- **main_takeaway:** at 0–2 searches model tokens are the largest individual meter; at 3+ searches search is.
- **caveat:** largest individual meter is not the same as more than half of total cost; threshold changes with the fixed assumptions.
- **alt_text:** Search cost rises by one cent per search and crosses the fixed 2.2-cent model-token line at the third search; session runtime stays at about 1.33 cents.
- **mobile_behavior:** full-width; keep the break-even annotation inside the plot area.
