# SITE HANDOFF — SECOND / PASS Agent Economics

This file is the implementation contract for Z.ai. Do not reinterpret the research.

## Canonical article

**File**  
`02_ARTICLE/an-ai-agent-is-no-longer-priced-in-tokens.md`

**Slug**  
`an-ai-agent-is-no-longer-priced-in-tokens`

**Recommended route**  
Use the site's current route convention for `AI / SECOND PASS`; do not invent a new content type.

**Section**  
AI

**Format**  
SECOND PASS

**Featured**  
true

**Status**  
review

**Author**  
Aditya

## Important source-format rules

- The `.md` file is the **only** public canonical article source.
- Do not generate a duplicate `.mdx`.
- The renderer owns the H1; do not insert another body H1.
- FIRST PASS comes from frontmatter; do not insert a second FIRST PASS block into the body.
- Keep `status: "review"` until Aditya approves publication.
- Structured source objects already exist in frontmatter.
- Inline article sourcing uses natural Markdown links. Do not replace them with opaque `[S1]` markers.

## Public-safe research files

Place these where the site can expose static downloads if desired:

- `03_RESEARCH/agent-billing-meters-2026-08-10.csv`
- `03_RESEARCH/agent-billing-meters-2026-08-10.json`
- `03_RESEARCH/agent-cost-worked-scenario.csv`
- `04_CHARTS/data/*.csv`

The billing-meter dataset is **supporting evidence**, not a full `/DATA` product. Do not create a new DATA page from it in this task.

## Charts

Preferred article order:

### 1. Agent billing path
Files:
- `04_CHARTS/chart-01-agent-billing-path.svg`
- PNG fallback

Placement:
Immediately after the opening explanation of the agent path.

### 2. Worked cost composition
Files:
- `04_CHARTS/chart-02-cost-waterfall.svg`
- PNG fallback

Placement:
Immediately after the first `/ CALCULATION` block.

### 3. Search-count sensitivity
Files:
- `04_CHARTS/chart-04-sensitivity.svg`
- PNG fallback

Placement:
Immediately after the search-dominance `/ CALCULATION`.

### 4. Provider base-meter + pricing-rule matrix
Files:
- `04_CHARTS/chart-03-meter-matrix.svg`
- PNG fallback

Placement:
At the start of the cross-provider billing section.

Captions, source basis, alt text and mobile rules are in `04_CHARTS/chart-specs.md`.

## Responsive behavior

Verify at:
1440 / 1024 / 820 / 768 / 430 / 390 / 375 px.

### Charts
- SVG preferred.
- Width 100% of figure container.
- Do not shrink labels below the site's normal caption size.
- Corrected taxonomy matrix may use bounded horizontal scroll on 375–430px; preserve the visual divider between four base meters and the two rule layers.
- Captions stay outside the scroll region so they remain readable.

### Tables
- Cost scale table should fit normal article width on desktop.
- On mobile, wrap in the site's bounded table scroller.
- No page-level horizontal overflow.
- Numeric columns should remain right-aligned.

### Equations
- Math blocks may scroll inside their own bounded container if needed.
- Never let an equation force page-level overflow.
- Currency prose such as `$0.01` remains normal text; do not rewrite it as inline math.

### Callouts
Map existing site article objects if available:
- `/ ASSUMPTION`
- `/ CALCULATION`
- `/ CLAIM CHECK`
- `/ INTELLIGENCE`

Do not create a new component system if simple existing callouts can render them.

## Social-stat recommendation

Primary OG: **do not use a scenario number**.

Reason: `$0.0653` and `3 searches` are specific to the illustrative Anthropic trace and can look universal when removed from context.

For a secondary calculation card, use:
`ILLUSTRATIVE TRACE / 2.20¢ TOKENS + 3.00¢ SEARCH + 1.33¢ RUNTIME = 6.53¢`

Keep `ILLUSTRATIVE TRACE` visible at all sizes.

## / INTELLIGENCE CTA

Use the article's existing block:

> Making an agent architecture, model-routing or infrastructure decision?  
> SECOND / PASS runs source-backed research sprints that apply this type of cost model to a specific production workload.  
> **START A RESEARCH BRIEF →**

Link `START A RESEARCH BRIEF →` to `/intelligence`.

Do not add price or checkout language.

## BRIEF

Today's full BRIEF is not part of this package.

Use `08_BRIEF/brief-summary.md` later when assembling the multi-article daily BRIEF.

Suggested link label:
`READ / PRICE THE AGENT PATH →`

## Internal QA — do not publish as article pages

- `00_MANIFEST.md`
- `01_EDITORIAL_DECISION.md`
- `05_QA/*`
- `06_DISTRIBUTION/*`
- `07_SOCIAL/asset-copy.md`
- `09_FOLLOWUPS/FOLLOWUP_EXTRACTIONS.md`
- `10_SITE_HANDOFF.md`

## Do not build

- CMS
- database
- authentication
- interactive cost calculator
- runtime chart library
- full Agent Cost Surface `/DATA` product
- provider leaderboard

Static Markdown + static SVG/PNG + optional static CSV/JSON downloads are sufficient.

## Publication-state handoff

Current frontmatter must remain:
- `status: "review"`
- `changeLog: []`

After human approval only, Z.ai may change the status to the site's published value and add a schema-valid change-log event equivalent to:
- `at: "2026-08-10"`
- `type: "published"`
- `note: "Initial publication."`

Do not record the prepublication editorial pass as a public correction.

## Pangram gate

This package is ready for the manual Pangram prose audit and human editorial approval. Pangram is not part of the site implementation step. Do not alter factual wording merely to chase a detector score.

## Final implementation check

Before changing article status:
- confirm every SVG/PNG loads;
- confirm the FIRST PASS renders from frontmatter;
- confirm there is one H1 only;
- confirm all source links work;
- confirm tables and equations do not overflow at 375px;
- confirm scenario labels remain visible;
- confirm `status` remains `review` and `changeLog` remains empty until human approval.
