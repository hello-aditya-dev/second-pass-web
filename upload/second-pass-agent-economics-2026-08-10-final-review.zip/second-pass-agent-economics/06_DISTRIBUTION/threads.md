# Threads

A simple way to price an AI agent:

Draw the task first.

MODEL → SEARCH → MODEL → TOOL → MODEL → ANSWER

Then label each billable step. The base units are usually some mix of tokens, calls, runtime and stored state. Product rules decide which charges apply.

In one illustrative Claude Managed Agents trace, the bill is 6.53¢: 2.20¢ model tokens, 3.00¢ search, 1.33¢ runtime.

Same model, different workflow shape, different dominant meter.

[ARTICLE URL]
