# LinkedIn — SECOND / PASS

**New / SECOND PASS**

**Token price no longer tells you what an AI agent costs**

SECOND / PASS mapped current agent billing into four base meter families: token volume, calls, runtime and stored state. Configuration modifiers and inclusion/applicability rules are treated separately because they change a meter's price or decide whether it applies.

Worked illustrative trace:
- model tokens: $0.0220
- web search: $0.0300
- session runtime: $0.0133
- total: $0.0653

With the other quantities fixed, the third search makes search the largest individual meter.

The release includes primary-source meter data, calculation ledger, corrected provider applicability rules and four static charts.

[ARTICLE URL]
