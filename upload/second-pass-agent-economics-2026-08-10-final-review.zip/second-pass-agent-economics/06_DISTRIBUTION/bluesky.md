# Bluesky

Token price is one part of an AI-agent bill.

Four base meter families: tokens / calls / runtime / stored state. Configuration and inclusion rules sit above them.

Illustrative Claude Managed Agents trace: $0.0220 tokens + $0.0300 search + $0.0133 runtime = $0.0653.

With the rest fixed, search becomes the largest individual meter on the 3rd search.

[ARTICLE URL]
