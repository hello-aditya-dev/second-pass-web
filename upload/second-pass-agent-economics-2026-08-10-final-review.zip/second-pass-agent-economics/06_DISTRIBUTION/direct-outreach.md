# Direct Technical Outreach

## Agent infrastructure / platform team

**Subject:** Source-backed agent cost stack: tokens + calls + runtime + stored state

I published a SECOND / PASS analysis that maps current public agent billing into four base meter families, with configuration and inclusion rules handled separately.

The worked example is a transparent provider-native trace rather than a provider ranking. Its main result is a break-even: with the stated token and runtime quantities fixed, the third web search makes search the largest individual meter.

The source table, scenario CSV and calculation ledger are included so the assumptions can be changed.

[ARTICLE URL]

— Aditya
Founder & Editor, SECOND / PASS

## Provider / developer-relations team

**Subject:** Fact-check invitation: SECOND / PASS agent billing analysis

I prepared a source-backed analysis of current AI-agent billing structures using your public pricing/tool documentation. It compares meter families and product rules, not overall provider economics.

If a pricing unit, product boundary or applicability rule is represented incorrectly, I would appreciate a correction with the relevant primary-source page.

[ARTICLE URL]

— Aditya
Founder & Editor, SECOND / PASS
