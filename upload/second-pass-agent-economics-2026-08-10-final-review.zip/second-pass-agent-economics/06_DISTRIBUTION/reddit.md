# Reddit

## Suggested title

I mapped the actual billing meters behind AI agents — token price is only one line

## Body

I wanted a cost model for agents that did not stop at `$ / million tokens`.

The useful structure ended up being four base meter families: token volume, calls/invocations, runtime, and stored state. Then there are two separate rule layers: configuration modifiers that change unit prices, and inclusion/applicability rules that decide whether a charge exists.

For one reproducible example I used Claude Managed Agents + Haiku 4.5. Illustrative quantities: 12k input, 2k output, 3 searches, 10 running minutes.

Cost: model tokens $0.0220; search $0.0300; runtime $0.0133; total $0.0653.

With the token and runtime quantities fixed, the third search is the first point where search becomes the largest individual meter. That is a scenario threshold, not typical agent behavior.

The package also audits a common accounting error: Managed Agents session runtime replaces separate Code Execution container-hour billing, and Anthropic says Messages API Batch/Fast/`inference_geo` modifiers do not apply to Managed Agents sessions.

[ARTICLE URL]
