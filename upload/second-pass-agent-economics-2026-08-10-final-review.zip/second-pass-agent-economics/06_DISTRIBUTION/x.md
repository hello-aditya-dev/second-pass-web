# X

## Thread

**1/** Token price still matters. It just does not price every part of an AI agent task.

Across current provider stacks, the base billing units fall into four families: tokens, calls, runtime and stored state.

**2/** Configuration is a different layer. Batch/Flex/Fast/Priority/context/region rules can change the price of a base meter. Allowances and product rules can remove or replace a charge.

**3/** Illustrative Claude Managed Agents trace:
12k input + 2k output + 3 searches + 10 running min

model tokens = $0.0220
search = $0.0300
runtime = $0.0133
total = **$0.0653**

**4/** Keep tokens + runtime fixed. Search is $0.01 each.
1 search = $0.01
2 = $0.02
3 = $0.03

The **third search** makes search the largest individual meter. Scenario threshold, not a universal rule.

**5/** One $0.01 search also equals, at the stated Haiku list prices:
10,000 input tokens
2,000 output tokens
7.5 running minutes

Billing equivalence, not performance equivalence.

**6/** Practical rule: trace one full task, attach the provider's actual meter to each step, apply configuration/inclusion rules, remove overlaps, then optimize the meter that matters on real traffic.

[ARTICLE URL]
