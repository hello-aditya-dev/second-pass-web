# Hacker News

## Title options

1. **Token price no longer tells you what an AI agent costs**
2. **Model tokens are only one part of an AI agent's API cost**
3. **A source-backed cost stack for AI agents: tokens, calls, runtime and storage**

## Optional first comment

I mapped current agent/tool billing across OpenAI, Anthropic, Google and xAI using provider docs, then built one provider-native trace instead of a cross-provider cheapest-agent ranking.

The framework separates four base meter families—token volume, calls, runtime and stored state—from configuration modifiers and inclusion/applicability rules.

The worked example is Claude Managed Agents + Haiku 4.5: 12k cumulative input tokens, 2k output tokens, 3 web searches and 10 running minutes. That is $0.0653: $0.0220 model tokens, $0.0300 search, $0.0133 runtime. With the other quantities fixed, the third search makes search the largest individual meter.

Anthropic's Managed Agents Batch/Fast/`inference_geo` exclusions are treated as product rules, not scenario switches. Raw meter data and calculation ledgers are included.
