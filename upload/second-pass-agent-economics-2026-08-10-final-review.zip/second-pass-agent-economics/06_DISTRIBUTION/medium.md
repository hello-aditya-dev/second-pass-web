# Medium Excerpt

## Title
The model is only one line on an AI agent's bill

Publish an excerpt only:
opening → four base meters → two rule layers → worked 6.53-cent trace → third-search threshold.

Stop before the detailed provider-structure section.

Footer:
> This is an excerpt from SECOND / PASS. The canonical research includes the source data, raw scenario, calculations and double-counting audit.

Canonical: [ARTICLE URL]
