# LinkedIn — Personal

The second SECOND / PASS research package changed one part of how I think about AI-agent pricing.

Using token prices is not the mistake. Treating them as the whole task cost is.

Current provider docs show four base meter families around agent work: token volume, calls, runtime and stored state. Configuration and inclusion rules sit above those meters and change what is actually billed.

One illustrative Claude Managed Agents trace uses 12k input tokens, 2k output tokens, 3 web searches and 10 running minutes. The cost is $0.0653: $0.0220 model tokens, $0.0300 search and $0.0133 runtime.

With everything else fixed, the third search is the first point where search becomes the largest individual meter. That is a break-even threshold, not a statement about typical agent behavior.

The article includes the source-backed meter data, raw scenario, calculations and double-counting audit.

[ARTICLE URL]
